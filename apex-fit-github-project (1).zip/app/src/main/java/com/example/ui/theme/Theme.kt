package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val ApexDarkColorScheme = darkColorScheme(
    primary = NeonLime,
    onPrimary = ObsidianBg,
    primaryContainer = Color(0x26BFFF00),
    onPrimaryContainer = NeonLime,
    secondary = ElectricCyan,
    onSecondary = ObsidianBg,
    secondaryContainer = Color(0x1F00FFFF),
    onSecondaryContainer = ElectricCyan,
    tertiary = CyberMagenta,
    onTertiary = Color.White,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = GlassSurface,
    onSurface = TextPrimary,
    surfaceVariant = GlassElevated,
    onSurfaceVariant = TextDim,
    outline = GlassBorder,
    error = AlertAmber,
    onError = ObsidianBg
)

@Composable
fun ApexFitTheme(
    isArabic: Boolean = true,
    content: @Composable () -> Unit
) {
    val direction = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        MaterialTheme(
            colorScheme = ApexDarkColorScheme,
            typography = apexTypography(isArabic),
            content = content
        )
    }
}
