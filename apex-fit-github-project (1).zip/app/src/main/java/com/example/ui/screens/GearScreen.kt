package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.NutritionData
import com.example.data.StringsData
import com.example.model.ApexUiState
import com.example.ui.components.Eyebrow
import com.example.ui.components.GlassCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassElevated
import com.example.ui.theme.NeonLime
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary

@Composable
fun GearScreen(
    state: ApexUiState,
    onAddToCart: (Int) -> Unit,
    onClearCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val totalUsd = state.cartIndices.sumOf { NutritionData.gear.getOrNull(it)?.priceUsd ?: 0 }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    eyebrow = StringsData.gearEyebrow.get(lang),
                    title = StringsData.gearTitle.get(lang),
                    badge = "${state.cartIndices.size} ${StringsData.inCart.get(lang)}",
                    eyebrowColor = ElectricCyan,
                    badgeColor = NeonLime
                )
            }

            items(NutritionData.gear, key = { it.id }) { item ->
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = GlassElevated,
                    border = BorderStroke(1.dp, GlassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.category.get(lang).uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricCyan
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = item.name.get(lang),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                            }
                            Text(
                                text = "$${item.priceUsd}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = NeonLime
                            )
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            item.specs.get(lang).forEach { spec ->
                                Text(
                                    text = "› $spec",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextDim
                                )
                            }
                        }

                        Surface(
                            shape = CircleShape,
                            color = NeonLime.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, NeonLime.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .clickable { onAddToCart(item.id) }
                                .testTag("gear_buy_${item.id}")
                        ) {
                            Text(
                                text = StringsData.addCart.get(lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonLime,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                            )
                        }
                    }
                }
            }

            item {
                GlassCard(neonBorder = NeonLime) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Eyebrow(text = StringsData.cartLbl.get(lang), color = NeonLime)
                        Text(
                            text = "$$totalUsd",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = NeonLime
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (state.cartIndices.isEmpty()) {
                        Text(
                            text = StringsData.emptyCart.get(lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextDim
                        )
                    } else {
                        state.cartIndices.forEachIndexed { idx, gearIdx ->
                            val gearItem = NutritionData.gear.getOrNull(gearIdx) ?: return@forEachIndexed
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = gearItem.name.get(lang),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "$${gearItem.priceUsd}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = NeonLime
                                )
                            }
                            if (idx < state.cartIndices.lastIndex) {
                                HorizontalDivider(color = GlassBorder)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = CircleShape,
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, GlassBorder),
                            modifier = Modifier
                                .clickable(onClick = onClearCart)
                                .testTag("clear_cart_button")
                        ) {
                            Text(
                                text = StringsData.clearCart.get(lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextDim,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = StringsData.usd.get(lang),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextDim
                    )
                }
            }
        }
    }
}
