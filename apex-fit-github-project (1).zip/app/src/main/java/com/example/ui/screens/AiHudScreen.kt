package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.data.StringsData
import com.example.model.ApexUiState
import com.example.model.ChatMessage
import com.example.model.PoseType
import com.example.ui.components.AnimatedNeonBar
import com.example.ui.components.Eyebrow
import com.example.ui.components.GlassCard
import com.example.ui.components.KineticFigureCanvas
import com.example.ui.components.SectionHeader
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassElevated
import com.example.ui.theme.NeonLime
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary

@Composable
fun AiHudScreen(
    state: ApexUiState,
    onToggleVoice: () -> Unit,
    onApplySwap: () -> Unit,
    onSendMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(state.chatMessages.size) {
        if (state.chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(state.chatMessages.size + 2)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 114.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                SectionHeader(
                    eyebrow = StringsData.aiEyebrow.get(lang),
                    title = StringsData.aiTitle.get(lang),
                    badge = StringsData.telem.get(lang),
                    eyebrowColor = ElectricCyan,
                    badgeColor = ElectricCyan
                )
            }

            // Live Telemetry Figure Card
            item {
                GlassCard(neonBorder = NeonLime) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Eyebrow(text = StringsData.liveSkeletal.get(lang), color = NeonLime)
                        Surface(
                            shape = CircleShape,
                            color = NeonLime.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, NeonLime.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = StringsData.formOk.get(lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonLime,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    KineticFigureCanvas(
                        pose = PoseType.SQUAT,
                        language = lang,
                        tempoSec = 1.4f,
                        muscleActivation = mapOf("quads" to 90, "glutes" to 82, "core" to 86, "hams" to 60),
                        autoPlay = true,
                        tagPrefix = "ai_squat"
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = StringsData.squatDepth.get(lang), style = MaterialTheme.typography.bodySmall, color = TextDim)
                            Text(text = StringsData.parallel.get(lang), style = MaterialTheme.typography.titleMedium, color = NeonLime)
                            Spacer(modifier = Modifier.height(4.dp))
                            AnimatedNeonBar(label = "", percent = 82, accent = NeonLime)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = StringsData.kneeTrack.get(lang), style = MaterialTheme.typography.bodySmall, color = TextDim)
                            Text(text = "98%", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
                            Spacer(modifier = Modifier.height(4.dp))
                            AnimatedNeonBar(label = "", percent = 98, accent = ElectricCyan)
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.04f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = NeonLime,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = StringsData.lumbar.get(lang),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // Voice Synth HUD
            item {
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        VoiceEqualizer(active = state.isSpeaking || state.voiceEnabled)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = StringsData.voiceHud.get(lang),
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                            Text(
                                text = if (state.voiceEnabled) StringsData.voiceOn.get(lang) else StringsData.voiceOff.get(lang),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextDim
                            )
                        }
                        Switch(
                            checked = state.voiceEnabled,
                            onCheckedChange = { onToggleVoice() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = ElectricCyan,
                                checkedTrackColor = ElectricCyan.copy(alpha = 0.35f),
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = Color.White.copy(alpha = 0.12f)
                            ),
                            modifier = Modifier.testTag("voice_hud_switch")
                        )
                    }
                }
            }

            // Chat History
            items(state.chatMessages, key = { it.id }) { msg ->
                ChatBubbleItem(
                    msg = msg,
                    state = state,
                    onApplySwap = onApplySwap
                )
            }

            // Quick Prompt Chips + Composer
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StringsData.aiQuickPrompts.forEachIndexed { idx, prompt ->
                        val txt = prompt.get(lang)
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.04f),
                            border = BorderStroke(1.dp, GlassBorder),
                            modifier = Modifier
                                .clickable { onSendMessage(txt) }
                                .testTag("ai_prompt_$idx")
                        ) {
                            Text(
                                text = txt,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextDim,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = CircleShape,
                    color = GlassElevated,
                    border = BorderStroke(1.dp, GlassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = { Text(StringsData.composer.get(lang), color = TextDim) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = {
                                if (inputText.isNotBlank()) {
                                    onSendMessage(inputText)
                                    inputText = ""
                                }
                            }),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("ai_composer_input")
                        )
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(NeonLime)
                                .clickable {
                                    if (inputText.isNotBlank()) {
                                        onSendMessage(inputText)
                                        inputText = ""
                                    }
                                }
                                .testTag("ai_send_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Send,
                                contentDescription = StringsData.send.get(lang),
                                tint = ObsidianBg,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceEqualizer(active: Boolean) {
    val transition = rememberInfiniteTransition(label = "eq")
    val barHeights = List(9) { idx ->
        transition.animateFloat(
            initialValue = 0.25f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(360 + (idx % 4) * 90, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "eq_$idx"
        )
    }
    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.Bottom,
        modifier = Modifier.height(26.dp)
    ) {
        barHeights.forEachIndexed { idx, anim ->
            val frac = if (active) anim.value else 0.30f
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height((24f * frac).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (idx % 2 == 0) ElectricCyan else NeonLime)
            )
        }
    }
}

@Composable
private fun ChatBubbleItem(
    msg: ChatMessage,
    state: ApexUiState,
    onApplySwap: () -> Unit
) {
    val lang = state.language
    if (msg.isUser) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color.White.copy(alpha = 0.08f),
                border = BorderStroke(1.dp, GlassBorder),
                modifier = Modifier.widthIn(max = 320.dp)
            ) {
                Text(
                    text = msg.text?.get(lang).orEmpty(),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary,
                    modifier = Modifier.padding(13.dp)
                )
            }
        }
    } else if (msg.isSwapCard) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = NeonLime, modifier = Modifier.size(16.dp))
                Text(
                    text = StringsData.coachNow.get(lang),
                    style = MaterialTheme.typography.labelMedium,
                    color = NeonLime
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = StringsData.coachSwap.get(lang),
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = NeonLime.copy(alpha = 0.07f),
                border = BorderStroke(1.dp, NeonLime.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = StringsData.swapTitle.get(lang),
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary
                        )
                        Text(
                            text = StringsData.swapSub.get(lang),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextDim
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onApplySwap,
                        shape = CircleShape,
                        colors = if (state.swappedShoulderProtocol) {
                            ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = NeonLime)
                        } else {
                            ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = ObsidianBg)
                        },
                        border = if (state.swappedShoulderProtocol) BorderStroke(1.dp, NeonLime) else null,
                        modifier = Modifier.testTag("apply_swap_button")
                    ) {
                        Text(
                            text = if (state.swappedShoulderProtocol) StringsData.applied.get(lang) else StringsData.apply.get(lang),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Rounded.Psychology, contentDescription = null, tint = NeonLime, modifier = Modifier.size(16.dp))
                Text(
                    text = StringsData.coachHead.get(lang),
                    style = MaterialTheme.typography.labelMedium,
                    color = NeonLime
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = msg.text?.get(lang).orEmpty(),
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary
            )
        }
    }
}
