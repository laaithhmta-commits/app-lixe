package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF0A0B0D)
val ObsidianDeep = Color(0xFF08090B)
val GlassSurface = Color(0xC716181D)
val GlassElevated = Color(0xDC16181D)
val GlassSubtle = Color(0x0DFFFFFF)
val GlassBorder = Color(0x18FFFFFF)
val GlassSheetBg = Color(0xFF101216)

val NeonLime = Color(0xFFBFFF00)
val ElectricCyan = Color(0xFF00FFFF)
val SolarGold = Color(0xFFFFFF00)
val CyberMagenta = Color(0xFFE100FF)
val AlertAmber = Color(0xFFFF9500)
val HeartRed = Color(0xFFFF4D6D)

val TextPrimary = Color(0xFFEDEFF2)
val TextSecondary = Color(0xFFC2C7D0)
val TextDim = Color(0xFF8A909C)
