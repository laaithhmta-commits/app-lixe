package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.MonitorHeart
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.MonitorHeart
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.StringsData
import com.example.model.AppLanguage
import com.example.model.AppTab
import com.example.ui.theme.AlertAmber
import com.example.ui.theme.CyberMagenta
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassElevated
import com.example.ui.theme.GlassSurface
import com.example.ui.theme.NeonLime
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    neonBorder: Color? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val border = neonBorder?.copy(alpha = 0.28f) ?: GlassBorder
    val bg = if (neonBorder != null) GlassElevated else GlassSurface
    Surface(
        modifier = modifier.revealOnEnter().fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = bg,
        border = BorderStroke(1.dp, border),
        tonalElevation = if (neonBorder != null) 4.dp else 1.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun PulsingDot(color: Color, size: Dp = 8.dp) {
    val transition = rememberInfiniteTransition(label = "dotPulse")
    val alpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dotAlpha"
    )
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(color.copy(alpha = alpha))
    )
}

@Composable
fun Eyebrow(
    text: String,
    color: Color = NeonLime,
    pulsing: Boolean = false
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        if (pulsing) {
            PulsingDot(color = color)
        }
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}

@Composable
fun SectionHeader(
    eyebrow: String,
    title: String,
    badge: String,
    eyebrowColor: Color = NeonLime,
    badgeColor: Color = NeonLime
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 2.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Eyebrow(text = eyebrow, color = eyebrowColor, pulsing = true)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.headlineLarge,
                color = TextPrimary
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Surface(
            shape = CircleShape,
            color = badgeColor.copy(alpha = 0.08f),
            border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.6f))
        ) {
            Text(
                text = badge,
                style = MaterialTheme.typography.labelSmall,
                color = badgeColor,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
            )
        }
    }
}

@Composable
fun CautionBanner(
    title: String,
    message: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = AlertAmber.copy(alpha = 0.09f),
        border = BorderStroke(1.dp, AlertAmber.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Rounded.WarningAmber,
                contentDescription = title,
                tint = AlertAmber,
                modifier = Modifier.size(18.dp)
            )
            Column {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = AlertAmber
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary
                )
            }
        }
    }
}

@Composable
fun NeonCtaButton(
    text: String,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier,
    outlined: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (pressed) 0.98f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "ctaPress"
    )
    val breathTransition = rememberInfiniteTransition(label = "ctaBreath")
    val glowDp by breathTransition.animateFloat(
        initialValue = 12f,
        targetValue = 22f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ctaGlow"
    )
    Button(
        onClick = onClick,
        shape = CircleShape,
        interactionSource = interaction,
        colors = if (outlined) {
            ButtonDefaults.buttonColors(
                containerColor = Color.Transparent,
                contentColor = NeonLime
            )
        } else {
            ButtonDefaults.buttonColors(
                containerColor = NeonLime,
                contentColor = ObsidianBg
            )
        },
        border = if (outlined) BorderStroke(1.dp, NeonLime.copy(alpha = 0.6f)) else null,
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
            }
            .then(
                if (!outlined) Modifier.shadow(glowDp.dp, CircleShape, ambientColor = NeonLime, spotColor = NeonLime)
                else Modifier
            )
            .testTag(testTag)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun AnimatedRing(
    percent: Int,
    color: Color,
    size: Dp = 90.dp,
    strokeWidth: Dp = 8.dp,
    centerContent: @Composable () -> Unit
) {
    val animatedSweep by animateFloatAsState(
        targetValue = (percent.coerceIn(0, 100) / 100f) * 360f,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "ringSweep"
    )
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(size)
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val strokePx = strokeWidth.toPx()
            val inset = strokePx / 2f
            val arcSize = Size(this.size.width - strokePx, this.size.height - strokePx)
            drawArc(
                color = Color.White.copy(alpha = 0.08f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
            drawArc(
                color = color.copy(alpha = 0.25f),
                startAngle = -90f,
                sweepAngle = animatedSweep,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = strokePx * 1.5f, cap = StrokeCap.Round)
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = animatedSweep,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
        }
        centerContent()
    }
}

@Composable
fun TopStatusBar(
    language: AppLanguage,
    onToggleLanguage: () -> Unit,
    onAlertsClick: () -> Unit
) {
    Surface(
        color = ObsidianBg.copy(alpha = 0.90f),
        border = BorderStroke(1.dp, GlassBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .statusBarsPadding()
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Canvas(modifier = Modifier.size(32.dp)) {
                    val w = size.width
                    val h = size.height
                    val aPath = Path().apply {
                        moveTo(w * 0.50f, h * 0.09f)
                        lineTo(w * 0.88f, h * 0.81f)
                        lineTo(w * 0.69f, h * 0.81f)
                        lineTo(w * 0.50f, h * 0.44f)
                        lineTo(w * 0.31f, h * 0.81f)
                        lineTo(w * 0.12f, h * 0.81f)
                        close()
                    }
                    drawPath(
                        path = aPath,
                        brush = Brush.verticalGradient(listOf(ElectricCyan, NeonLime))
                    )
                    drawRect(
                        color = NeonLime,
                        topLeft = Offset(w * 0.28f, h * 0.69f),
                        size = Size(w * 0.44f, h * 0.08f)
                    )
                    val chevron = Path().apply {
                        moveTo(w * 0.40f, h * 0.84f)
                        lineTo(w * 0.60f, h * 0.84f)
                        lineTo(w * 0.50f, h * 0.94f)
                        close()
                    }
                    drawPath(chevron, color = ElectricCyan)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "APEX ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "FIT",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NeonLime,
                        letterSpacing = 1.2.sp
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.04f),
                    border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .height(38.dp)
                        .clickable(onClick = onToggleLanguage)
                        .testTag("language_toggle_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text(
                            text = "عربي",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (language.isArabic) ElectricCyan else TextDim
                        )
                        Text(text = "|", style = MaterialTheme.typography.labelSmall, color = TextDim)
                        Text(
                            text = "EN",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (!language.isArabic) ElectricCyan else TextDim
                        )
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = ElectricCyan.copy(alpha = 0.06f),
                    border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        PulsingDot(color = ElectricCyan, size = 7.dp)
                        Text(
                            text = StringsData.live.get(language),
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricCyan,
                            maxLines = 1
                        )
                    }
                }

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.05f))
                        .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                        .clickable(onClick = onAlertsClick)
                        .testTag("alerts_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Notifications,
                        contentDescription = "Notifications",
                        tint = TextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun FloatingBottomDock(
    currentTab: AppTab,
    language: AppLanguage,
    cartCount: Int,
    onSelectTab: (AppTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = Color(0xEB121418),
            border = BorderStroke(1.dp, GlassBorder),
            shadowElevation = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                DockTabItem(
                    selected = currentTab == AppTab.WORKOUTS,
                    label = StringsData.tabWorkouts.get(language),
                    icon = if (currentTab == AppTab.WORKOUTS) Icons.Rounded.FitnessCenter else Icons.Outlined.FitnessCenter,
                    onClick = { onSelectTab(AppTab.WORKOUTS) },
                    testTag = "nav_workouts",
                    modifier = Modifier.weight(1f)
                )
                DockTabItem(
                    selected = currentTab == AppTab.INTAKE,
                    label = StringsData.tabIntake.get(language),
                    icon = if (currentTab == AppTab.INTAKE) Icons.Rounded.MonitorHeart else Icons.Outlined.MonitorHeart,
                    onClick = { onSelectTab(AppTab.INTAKE) },
                    testTag = "nav_intake",
                    modifier = Modifier.weight(1f)
                )

                // Center AI HUD orb spacer
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.width(68.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .offset(y = (-14).dp)
                            .size(56.dp)
                            .shadow(
                                elevation = if (currentTab == AppTab.AI) 22.dp else 14.dp,
                                shape = CircleShape,
                                ambientColor = NeonLime,
                                spotColor = NeonLime
                            )
                            .clip(CircleShape)
                            .background(NeonLime)
                            .clickable { onSelectTab(AppTab.AI) }
                            .testTag("nav_ai")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Psychology,
                            contentDescription = StringsData.tabAI.get(language),
                            tint = ObsidianBg,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                DockTabItem(
                    selected = currentTab == AppTab.NUTRITION,
                    label = StringsData.tabNutrition.get(language),
                    icon = if (currentTab == AppTab.NUTRITION) Icons.Rounded.Restaurant else Icons.Outlined.Restaurant,
                    onClick = { onSelectTab(AppTab.NUTRITION) },
                    testTag = "nav_nutrition",
                    modifier = Modifier.weight(1f)
                )
                DockTabItem(
                    selected = currentTab == AppTab.GEAR,
                    label = StringsData.tabGear.get(language),
                    icon = if (currentTab == AppTab.GEAR) Icons.Rounded.ShoppingBag else Icons.Outlined.ShoppingBag,
                    badgeCount = cartCount,
                    onClick = { onSelectTab(AppTab.GEAR) },
                    testTag = "nav_gear",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun DockTabItem(
    selected: Boolean,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier,
    badgeCount: Int = 0
) {
    val tint = if (selected) NeonLime else TextDim
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .height(50.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Box {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = tint,
                    modifier = Modifier.size(20.dp)
                )
                if (badgeCount > 0) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 6.dp, y = (-4).dp)
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(CyberMagenta)
                    ) {
                        Text(
                            text = badgeCount.toString(),
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                            color = Color.White
                        )
                    }
                }
            }
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                color = tint,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
