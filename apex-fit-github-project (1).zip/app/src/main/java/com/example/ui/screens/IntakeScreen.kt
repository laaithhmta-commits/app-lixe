package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.StringsData
import com.example.model.ApexUiState
import com.example.model.Equipment
import com.example.model.PsychState
import com.example.model.TensionZone
import com.example.model.ZoneStatus
import com.example.ui.components.AnimatedRing
import com.example.ui.components.Eyebrow
import com.example.ui.components.GlassCard
import com.example.ui.components.NeonCtaButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.AlertAmber
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonLime
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import kotlin.math.roundToInt

@Composable
fun IntakeScreen(
    state: ApexUiState,
    onSelectPsych: (PsychState) -> Unit,
    onUpdateSleep: (Float) -> Unit,
    onUpdateHrv: (Int) -> Unit,
    onUpdateRhr: (Int) -> Unit,
    onCycleZone: (TensionZone) -> Unit,
    onToggleEquipment: (Equipment) -> Unit,
    onApplyRegimen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val sleepHoursInt = state.sleepHours.toInt()
    val sleepMins = ((state.sleepHours - sleepHoursInt) * 60f).roundToInt()
    val sleepFormatted = "${sleepHoursInt}h ${sleepMins.toString().padStart(2, '0')}m ${StringsData.deepSleep.get(lang)}"

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                SectionHeader(
                    eyebrow = StringsData.intakeEyebrow.get(lang),
                    title = StringsData.intakeTitle.get(lang),
                    badge = StringsData.live.get(lang),
                    eyebrowColor = ElectricCyan,
                    badgeColor = ElectricCyan
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = StringsData.intakeNote.get(lang),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextDim
                )
            }

            // Psychological State
            item {
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = StringsData.psyState.get(lang),
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Surface(
                            shape = CircleShape,
                            color = ElectricCyan.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = StringsData.psychName(state.psych, lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricCyan,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PsychState.entries.forEach { psy ->
                            val selected = state.psych == psy
                            val icon = when (psy) {
                                PsychState.DRAINED -> Icons.Rounded.WaterDrop
                                PsychState.FATIGUED -> Icons.Rounded.DarkMode
                                PsychState.NEUTRAL -> Icons.Rounded.WbSunny
                                PsychState.FOCUSED -> Icons.Rounded.Psychology
                                PsychState.PEAK -> Icons.Rounded.Bolt
                            }
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (selected) ElectricCyan.copy(alpha = 0.10f) else Color.Transparent,
                                border = BorderStroke(1.dp, if (selected) ElectricCyan else GlassBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onSelectPsych(psy) }
                                    .testTag("psych_${psy.key}")
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(5.dp),
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = StringsData.psychName(psy, lang),
                                        tint = if (selected) ElectricCyan else TextDim,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = StringsData.psychName(psy, lang),
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                        color = if (selected) ElectricCyan else TextDim,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Autonomic Recovery Ring + Sliders
            item {
                GlassCard(neonBorder = NeonLime) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        AnimatedRing(
                            percent = state.recoveryPercent,
                            color = ElectricCyan,
                            size = 116.dp,
                            strokeWidth = 9.dp
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${state.recoveryPercent}%",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = ElectricCyan
                                )
                                Text(
                                    text = StringsData.recovery.get(lang),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = TextDim
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Eyebrow(text = StringsData.autonomic.get(lang), color = ElectricCyan)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = sleepFormatted,
                                style = MaterialTheme.typography.titleLarge,
                                color = TextPrimary
                            )
                            Text(
                                text = StringsData.sleepArch.get(lang),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextDim
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${state.hrvMs} ms ${StringsData.hrvLbl.get(lang)} · ${state.rhrBpm} bpm",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextDim
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    IntakeSlider(
                        label = StringsData.sleepLbl.get(lang),
                        valueText = "${state.sleepHours}h",
                        value = state.sleepHours,
                        range = 4f..10f,
                        onValueChange = onUpdateSleep,
                        testTag = "sleep_slider"
                    )
                    IntakeSlider(
                        label = StringsData.hrvLbl.get(lang),
                        valueText = "${state.hrvMs} ms",
                        value = state.hrvMs.toFloat(),
                        range = 30f..100f,
                        onValueChange = { onUpdateHrv(it.roundToInt()) },
                        testTag = "hrv_slider"
                    )
                    IntakeSlider(
                        label = StringsData.rhrLbl.get(lang),
                        valueText = "${state.rhrBpm} bpm",
                        value = state.rhrBpm.toFloat(),
                        range = 40f..70f,
                        onValueChange = { onUpdateRhr(it.roundToInt()) },
                        testTag = "rhr_slider"
                    )
                }
            }

            // Biomechanical Tension Zones
            item {
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = StringsData.tension.get(lang),
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.04f),
                            border = BorderStroke(1.dp, GlassBorder)
                        ) {
                            Text(
                                text = "3 ${StringsData.zonesLogged.get(lang)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextDim,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = StringsData.tapZone.get(lang),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextDim
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    TensionZone.entries.forEach { zone ->
                        val status = state.zones[zone] ?: ZoneStatus.FRESH
                        val statusColor = if (status == ZoneStatus.FRESH || status == ZoneStatus.READY) NeonLime else AlertAmber
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White.copy(alpha = 0.03f),
                            border = BorderStroke(1.dp, GlassBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                                .clickable { onCycleZone(zone) }
                                .testTag("zone_${zone.key}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = StringsData.zoneName(zone, lang),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${StringsData.zoneStatusName(status, lang)} · ${status.pct}%",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = statusColor
                                )
                            }
                        }
                    }
                }
            }

            // Hardware & Logistics
            item {
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = StringsData.hardware.get(lang),
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.04f),
                            border = BorderStroke(1.dp, GlassBorder)
                        ) {
                            Text(
                                text = StringsData.multi.get(lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextDim,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    val rows = Equipment.entries.chunked(2)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        rows.forEach { pair ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                pair.forEach { eq ->
                                    val selected = if (eq == Equipment.NONE) state.ownedEquipment.isEmpty() else eq in state.ownedEquipment
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (selected) NeonLime.copy(alpha = 0.08f) else Color.Transparent,
                                        border = BorderStroke(1.dp, if (selected) NeonLime.copy(alpha = 0.6f) else GlassBorder),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { onToggleEquipment(eq) }
                                            .testTag("equip_${eq.id}")
                                    ) {
                                        Text(
                                            text = StringsData.equipmentName(eq, lang),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = if (selected) NeonLime else TextDim,
                                            modifier = Modifier.padding(12.dp)
                                        )
                                    }
                                }
                                if (pair.size == 1) Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            item {
                NeonCtaButton(
                    text = StringsData.applyRegimen.get(lang),
                    onClick = onApplyRegimen,
                    testTag = "apply_regimen_button"
                )
            }
        }
    }
}

@Composable
private fun IntakeSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    testTag: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
            Text(text = valueText, style = MaterialTheme.typography.labelMedium, color = ElectricCyan)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = ElectricCyan,
                activeTrackColor = ElectricCyan,
                inactiveTrackColor = Color.White.copy(alpha = 0.10f)
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}
