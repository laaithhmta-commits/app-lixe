package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NutritionAcademyData
import com.example.data.NutritionData
import com.example.data.StringsData
import com.example.model.ApexUiState
import com.example.model.AppLanguage
import com.example.model.FactCategory
import com.example.model.NutrientGroup
import com.example.model.NutrientGuideItem
import com.example.model.Recipe
import com.example.ui.components.AnimatedRing
import com.example.ui.components.Eyebrow
import com.example.ui.components.GlassCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.AlertAmber
import com.example.ui.theme.CyberMagenta
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassElevated
import com.example.ui.theme.NeonLime
import com.example.ui.theme.SolarGold
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Calendar
import kotlin.math.roundToInt

private const val GOAL_KCAL = 2800
private const val GOAL_P = 190
private const val GOAL_C = 280
private const val GOAL_F = 75
private const val GOAL_WATER = 4000

@Composable
fun NutritionScreen(
    state: ApexUiState,
    onAddWater: () -> Unit,
    onLogRecipe: (Int) -> Unit,
    onFactQueryChange: (String) -> Unit,
    onSelectFactCategory: (FactCategory?) -> Unit,
    onSelectNutrientGroup: (NutrientGroup?) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val lg = state.loggedMacros
    val kcalPct = ((lg.kcal.toFloat() / GOAL_KCAL) * 100f).roundToInt().coerceIn(0, 100)
    val waterFraction by animateFloatAsState(
        targetValue = (state.waterMl.toFloat() / GOAL_WATER).coerceIn(0f, 1f),
        animationSpec = tween(700, easing = FastOutSlowInEasing),
        label = "waterFill"
    )

    val filteredNutrients = remember(state.nutrientFilter) {
        NutritionAcademyData.nutrients.filter { state.nutrientFilter == null || it.group == state.nutrientFilter }
    }
    var expandedNutrientId by remember { mutableStateOf<String?>("protein") }

    val spotlightFact = remember {
        val dayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        NutritionData.facts[dayOfYear % NutritionData.facts.size]
    }

    val filteredFacts = remember(state.factQuery, state.factCategoryFilter) {
        val q = state.factQuery.trim().lowercase()
        NutritionData.facts.filter { fact ->
            val catOk = state.factCategoryFilter == null || fact.category == state.factCategoryFilter
            val qOk = q.isEmpty() ||
                fact.title.en.lowercase().contains(q) ||
                fact.title.ar.lowercase().contains(q) ||
                fact.body.en.lowercase().contains(q) ||
                fact.body.ar.lowercase().contains(q)
            catOk && qOk
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                SectionHeader(
                    eyebrow = StringsData.fuelEyebrow.get(lang),
                    title = StringsData.fuelTitle.get(lang),
                    badge = StringsData.synced.get(lang)
                )
            }

            // Macro & Hydration HUD Card
            item {
                GlassCard(neonBorder = NeonLime) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = StringsData.dailyGoal.get(lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextDim
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = lg.kcal.toString(),
                                    style = MaterialTheme.typography.headlineLarge,
                                    color = NeonLime
                                )
                                Text(
                                    text = " / $GOAL_KCAL ${StringsData.kcal.get(lang)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextDim,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                            }
                        }
                        AnimatedRing(percent = kcalPct, color = NeonLime, size = 84.dp, strokeWidth = 8.dp) {
                            Text(
                                text = "$kcalPct%",
                                style = MaterialTheme.typography.labelMedium,
                                color = NeonLime
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MacroRingColumn(lg.proteinG, GOAL_P, SolarGold, StringsData.protein.get(lang), Modifier.weight(1f))
                        MacroRingColumn(lg.carbsG, GOAL_C, NeonLime, StringsData.carbs.get(lang), Modifier.weight(1f))
                        MacroRingColumn(lg.fatsG, GOAL_F, CyberMagenta, StringsData.fats.get(lang), Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = ElectricCyan.copy(alpha = 0.05f),
                        border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Icon(Icons.Rounded.WaterDrop, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(16.dp))
                                    Text(
                                        text = StringsData.hydration.get(lang),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ElectricCyan
                                    )
                                }
                                Text(
                                    text = "${String.format("%.1f", state.waterMl / 1000f)}L / ${String.format("%.1f", GOAL_WATER / 1000f)}L",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.White.copy(alpha = 0.08f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(waterFraction)
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Brush.horizontalGradient(listOf(ElectricCyan, NeonLime)))
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                shape = CircleShape,
                                color = NeonLime.copy(alpha = 0.08f),
                                border = BorderStroke(1.dp, NeonLime.copy(alpha = 0.5f)),
                                modifier = Modifier
                                    .clickable(onClick = onAddWater)
                                    .testTag("add_water_button")
                            ) {
                                Text(
                                    text = StringsData.add250.get(lang),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NeonLime,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Anabolic Queue
            item {
                Text(
                    text = StringsData.queue.get(lang),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
            }

            itemsIndexed(NutritionData.recipes, key = { _, r -> "q_${r.id}" }) { idx, recipe ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White.copy(alpha = 0.03f),
                    border = BorderStroke(1.dp, GlassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = recipe.kcal.toString(),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = NeonLime
                            )
                            Text(
                                text = StringsData.kcal.get(lang),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                color = TextDim
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = recipe.name.get(lang),
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                            Text(
                                text = "${recipe.tag} · ${recipe.time.get(lang)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricCyan
                            )
                            Text(
                                text = "P ${recipe.proteinG}g · C ${recipe.carbsG}g · F ${recipe.fatsG}g",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextDim
                            )
                        }
                        Surface(
                            shape = CircleShape,
                            color = NeonLime.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, NeonLime.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .clickable { onLogRecipe(idx) }
                                .testTag("log_meal_$idx")
                        ) {
                            Text(
                                text = StringsData.log.get(lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonLime,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                            )
                        }
                    }
                }
            }

            // Full Recipes with Clear Food Photos
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = StringsData.recipe.get(lang),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
            }

            items(NutritionData.recipes, key = { "rec_${it.id}" }) { recipe ->
                RecipeFullCard(recipe = recipe, language = lang)
            }

            // Learn Nutrition · Macronutrients & Micronutrients Academy
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = StringsData.academyTitle.get(lang),
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    Surface(
                        shape = CircleShape,
                        color = NeonLime.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, NeonLime.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = NutritionAcademyData.nutrients.size.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonLime,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = StringsData.academySubtitle.get(lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextDim
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChipPill(
                        label = StringsData.all.get(lang),
                        selected = state.nutrientFilter == null,
                        onClick = { onSelectNutrientGroup(null) },
                        testTag = "nutrient_cat_all"
                    )
                    NutrientGroup.entries.forEach { grp ->
                        FilterChipPill(
                            label = StringsData.nutrientGroupName(grp, lang),
                            selected = state.nutrientFilter == grp,
                            onClick = { onSelectNutrientGroup(grp) },
                            testTag = "nutrient_cat_${grp.id}"
                        )
                    }
                }
            }

            items(filteredNutrients, key = { "nut_${it.id}" }) { item ->
                NutrientAcademyCard(
                    item = item,
                    language = lang,
                    expanded = expandedNutrientId == item.id,
                    onToggle = {
                        expandedNutrientId = if (expandedNutrientId == item.id) null else item.id
                    }
                )
            }

            // 100 Bio-Synergy Food Facts
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = StringsData.factsTitle.get(lang),
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.04f),
                        border = BorderStroke(1.dp, GlassBorder)
                    ) {
                        Text(
                            text = NutritionData.facts.size.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricCyan,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = state.factQuery,
                    onValueChange = onFactQueryChange,
                    placeholder = { Text(StringsData.searchFacts.get(lang), color = TextDim) },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = ElectricCyan) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White.copy(alpha = 0.05f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.03f),
                        focusedBorderColor = ElectricCyan.copy(alpha = 0.6f),
                        unfocusedBorderColor = GlassBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("facts_search_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChipPill(
                        label = StringsData.all.get(lang),
                        selected = state.factCategoryFilter == null,
                        onClick = { onSelectFactCategory(null) },
                        testTag = "fact_cat_all"
                    )
                    FactCategory.entries.forEach { cat ->
                        FilterChipPill(
                            label = StringsData.factCategoryName(cat, lang),
                            selected = state.factCategoryFilter == cat,
                            onClick = { onSelectFactCategory(cat) },
                            testTag = "fact_cat_${cat.index}"
                        )
                    }
                }
            }

            // Daily Synergy Spotlight
            item {
                GlassCard(neonBorder = CyberMagenta) {
                    Eyebrow(text = StringsData.spotlight.get(lang), color = CyberMagenta)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = spotlightFact.title.get(lang),
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = spotlightFact.body.get(lang),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            item {
                Text(
                    text = "${StringsData.showing.get(lang)} ${filteredFacts.size} ${StringsData.of.get(lang)} ${NutritionData.facts.size}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextDim
                )
            }

            if (filteredFacts.isEmpty()) {
                item {
                    Text(
                        text = StringsData.noFacts.get(lang),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextDim
                    )
                }
            } else {
                items(filteredFacts, key = { it.number }) { fact ->
                    val catColor = when (fact.category) {
                        FactCategory.MUSCLE_SYNTHESIS -> NeonLime
                        FactCategory.FAT_LOSS -> AlertAmber
                        FactCategory.GUT_ABSORPTION -> ElectricCyan
                        FactCategory.JOINT_RECOVERY -> SolarGold
                        FactCategory.BRAIN_FOCUS -> CyberMagenta
                    }
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.03f),
                        border = BorderStroke(1.dp, GlassBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "#${fact.number.toString().padStart(3, '0')} · ${StringsData.factCategoryName(fact.category, lang)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = catColor
                            )
                            Spacer(modifier = Modifier.height(5.dp))
                            Text(
                                text = fact.title.get(lang),
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = fact.body.get(lang),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MacroRingColumn(
    value: Int,
    goal: Int,
    color: Color,
    label: String,
    modifier: Modifier = Modifier
) {
    val pct = ((value.toFloat() / goal) * 100f).roundToInt().coerceIn(0, 100)
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        AnimatedRing(percent = pct, color = color, size = 80.dp, strokeWidth = 7.dp) {
            Text(
                text = value.toString(),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
        Text(
            text = "$label / ${goal}g",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
            color = color,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun RecipeFullCard(recipe: Recipe, language: AppLanguage) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = GlassElevated,
        border = BorderStroke(1.dp, GlassBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4f / 3f)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, NeonLime.copy(alpha = 0.28f), RoundedCornerShape(14.dp))
            ) {
                Image(
                    painter = painterResource(id = recipe.imageRes),
                    contentDescription = recipe.name.get(language),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "${recipe.tag} · ${recipe.prepMin} ${StringsData.min.get(language)} ${StringsData.prep.get(language)}",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricCyan
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = recipe.name.get(language),
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary
            )
            Text(
                text = recipe.time.get(language),
                style = MaterialTheme.typography.bodySmall,
                color = TextDim
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Dedicated Recipe Benefit Box
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = NeonLime.copy(alpha = 0.07f),
                border = BorderStroke(1.dp, NeonLime.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = StringsData.recipeBenefit.get(language),
                        tint = NeonLime,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = StringsData.recipeBenefit.get(language).uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonLime
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = recipe.benefit.get(language),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatTile(recipe.kcal.toString(), StringsData.kcal.get(language), NeonLime, Modifier.weight(1f))
                StatTile("${recipe.proteinG}g", StringsData.protein.get(language), SolarGold, Modifier.weight(1f))
                StatTile("${recipe.carbsG}g", StringsData.carbs.get(language), NeonLime, Modifier.weight(1f))
                StatTile("${recipe.fatsG}g", StringsData.fats.get(language), CyberMagenta, Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(12.dp))
            Eyebrow(text = StringsData.nutritionFacts.get(language), color = ElectricCyan)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatTile(recipe.nutrition.serving.get(language), StringsData.serving.get(language), TextPrimary, Modifier.weight(1f))
                StatTile("${recipe.nutrition.fiberG}g", StringsData.fiber.get(language), TextPrimary, Modifier.weight(1f))
                StatTile("${recipe.nutrition.sodiumMg}mg", StringsData.sodium.get(language), TextPrimary, Modifier.weight(1f))
                StatTile("${recipe.nutrition.sugarG}g", StringsData.sugar.get(language), TextPrimary, Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "${StringsData.basics.get(language)}: ${recipe.basics.get(language)}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(12.dp))
            Eyebrow(text = StringsData.ingredients.get(language), color = ElectricCyan)
            Spacer(modifier = Modifier.height(6.dp))
            recipe.ingredients.forEach { ing ->
                Text(
                    text = "› ${ing.get(language)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Eyebrow(text = StringsData.method.get(language), color = ElectricCyan)
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                recipe.steps.get(language).forEachIndexed { idx, step ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.03f),
                        border = BorderStroke(1.dp, GlassBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = (idx + 1).toString(),
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricCyan
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = step,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatTile(
    value: String,
    label: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White.copy(alpha = 0.03f),
        border = BorderStroke(1.dp, GlassBorder),
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                color = valueColor,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                color = TextDim,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun NutrientAcademyCard(
    item: NutrientGuideItem,
    language: AppLanguage,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    val accent = when (item.group) {
        NutrientGroup.MACRO -> NeonLime
        NutrientGroup.VITAMIN -> ElectricCyan
        NutrientGroup.MINERAL -> SolarGold
    }
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (expanded) GlassElevated else Color.White.copy(alpha = 0.03f),
        border = BorderStroke(1.dp, if (expanded) accent.copy(alpha = 0.45f) else GlassBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .testTag("nutrient_card_${item.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = StringsData.nutrientGroupName(item.group, language).uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = accent
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = item.name.get(language),
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = item.subtitle.get(language),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextDim
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    contentDescription = item.name.get(language),
                    tint = accent,
                    modifier = Modifier.size(22.dp)
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier.padding(top = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NutrientDetailBlock(
                        title = StringsData.nutrientRole.get(language),
                        body = item.role.get(language),
                        accent = accent
                    )
                    NutrientDetailBlock(
                        title = StringsData.nutrientTarget.get(language),
                        body = item.dailyTarget.get(language),
                        accent = ElectricCyan
                    )
                    NutrientDetailBlock(
                        title = StringsData.nutrientSources.get(language),
                        body = item.foodSources.get(language),
                        accent = NeonLime
                    )
                    NutrientDetailBlock(
                        title = StringsData.nutrientTip.get(language),
                        body = item.absorptionTip.get(language),
                        accent = CyberMagenta
                    )
                }
            }
        }
    }
}

@Composable
private fun NutrientDetailBlock(
    title: String,
    body: String,
    accent: Color
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White.copy(alpha = 0.03f),
        border = BorderStroke(1.dp, GlassBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(11.dp)) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = accent
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = body,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary
            )
        }
    }
}
