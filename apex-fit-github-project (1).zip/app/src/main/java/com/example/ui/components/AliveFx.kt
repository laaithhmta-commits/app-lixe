package com.example.ui.components

import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyberMagenta
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonLime
import kotlin.math.cos
import kotlin.math.sin

/** Slow, drifting neon orbs behind the whole app. Uses only the existing palette. */
@Composable
fun AmbientOrbs(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "ambientOrbs")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbPhase"
    )
    Canvas(modifier = modifier.fillMaxSize()) {
        val base = (2.0 * Math.PI * phase).toFloat()
        val radius = size.maxDimension * 0.42f

        fun orb(color: Color, cx: Float, cy: Float, angle: Float, ampX: Float, ampY: Float, alpha: Float) {
            val center = Offset(cx + cos(angle) * ampX, cy + sin(angle) * ampY)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color.copy(alpha = alpha), Color.Transparent),
                    center = center,
                    radius = radius
                ),
                radius = radius,
                center = center
            )
        }

        orb(NeonLime, size.width * 0.15f, size.height * 0.08f, base, size.width * 0.06f, size.height * 0.03f, 0.10f)
        orb(ElectricCyan, size.width * 0.90f, size.height * 0.45f, base + 2.1f, size.width * 0.05f, size.height * 0.04f, 0.07f)
        orb(CyberMagenta, size.width * 0.40f, size.height * 0.95f, base + 4.2f, size.width * 0.05f, size.height * 0.03f, 0.06f)
    }
}

/** Fade-and-rise entrance with a spring-like curve, for cards as they first appear. */
@Composable
fun Modifier.revealOnEnter(delayMs: Int = 0): Modifier {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (delayMs > 0) kotlinx.coroutines.delay(delayMs.toLong())
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 650, easing = CubicBezierEasing(0.16f, 1f, 0.3f, 1f))
        )
    }
    return this.graphicsLayer {
        alpha = progress.value
        translationY = (1f - progress.value) * 18.dp.toPx()
    }
}

/** Tactile press feedback: a springy scale-down while the given interaction source is pressed. */
@Composable
fun Modifier.pressScale(interaction: MutableInteractionSource, pressedScale: Float = 0.97f): Modifier {
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "pressScale"
    )
    return this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}
