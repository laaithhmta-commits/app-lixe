package com.example

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.ExerciseData
import com.example.model.AppTab
import com.example.ui.components.ExerciseGuideBottomSheet
import com.example.ui.components.FloatingBottomDock
import com.example.ui.components.LiveSessionOverlay
import com.example.ui.components.TopStatusBar
import com.example.ui.components.WorkoutDetailBottomSheet
import com.example.ui.screens.AiHudScreen
import com.example.ui.screens.GearScreen
import com.example.ui.screens.IntakeScreen
import com.example.ui.screens.NutritionScreen
import com.example.ui.screens.WorkoutsScreen
import com.example.ui.theme.ApexFitTheme
import com.example.ui.components.AmbientOrbs
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonLime
import com.example.ui.theme.ObsidianBg
import com.example.viewmodel.ApexViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        setContent {
            val viewModel: ApexViewModel = viewModel()
            ApexFitApp(viewModel = viewModel)
        }
    }
}

@Composable
fun ApexFitApp(viewModel: ApexViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    ApexFitTheme(isArabic = state.language.isArabic) {
        if (state.tab != AppTab.WORKOUTS &&
            state.selectedWorkoutId == null &&
            state.selectedExerciseId == null &&
            state.activeSession == null
        ) {
            BackHandler {
                viewModel.selectTab(AppTab.WORKOUTS)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBg)
        ) {
            AmbientOrbs()
            // Ambient Dark Glassmorphic Neon Radial Backdrop
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(NeonLime.copy(alpha = 0.08f), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.06f),
                        radius = size.maxDimension * 0.48f
                    ),
                    radius = size.maxDimension * 0.48f,
                    center = Offset(size.width * 0.15f, size.height * 0.06f)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(ElectricCyan.copy(alpha = 0.07f), Color.Transparent),
                        center = Offset(size.width * 0.90f, size.height * 0.92f),
                        radius = size.maxDimension * 0.45f
                    ),
                    radius = size.maxDimension * 0.45f,
                    center = Offset(size.width * 0.90f, size.height * 0.92f)
                )
            }

            Column(modifier = Modifier.fillMaxSize()) {
                TopStatusBar(
                    language = state.language,
                    onToggleLanguage = viewModel::toggleLanguage,
                    onAlertsClick = viewModel::showNoAlertsToast
                )

                Box(modifier = Modifier.weight(1f)) {
                    AnimatedContent(
                        targetState = state.tab,
                        transitionSpec = {
                            (fadeIn(tween(240)) + slideInVertically(tween(240)) { it / 24 }) togetherWith
                                fadeOut(tween(180))
                        },
                        label = "tabTransition"
                    ) { tab ->
                        when (tab) {
                            AppTab.WORKOUTS -> {
                                val heroWo = viewModel.heroWorkout(state)
                                val leadSpec = heroWo.exercises.first()
                                val heroEx = viewModel.resolveExercise(leadSpec.exerciseId, state)
                                WorkoutsScreen(
                                    state = state,
                                    heroWorkout = heroWo,
                                    heroLeadExercise = heroEx,
                                    onToggleStreakDay = viewModel::toggleStreakDay,
                                    onOpenWorkout = viewModel::openWorkout,
                                    onOpenExercise = viewModel::openExerciseGuide,
                                    onSelectProgramFilter = viewModel::setProgramFilter,
                                    onSelectExerciseCategory = viewModel::setExerciseCategoryFilter,
                                    onSearchQueryChange = viewModel::setExerciseQuery
                                )
                            }

                            AppTab.INTAKE -> {
                                IntakeScreen(
                                    state = state,
                                    onSelectPsych = viewModel::setPsychState,
                                    onUpdateSleep = viewModel::updateSleep,
                                    onUpdateHrv = viewModel::updateHrv,
                                    onUpdateRhr = viewModel::updateRhr,
                                    onCycleZone = viewModel::cycleZone,
                                    onToggleEquipment = viewModel::toggleEquipment,
                                    onApplyRegimen = viewModel::applyAndGenerateRegimen
                                )
                            }

                            AppTab.AI -> {
                                AiHudScreen(
                                    state = state,
                                    onToggleVoice = viewModel::toggleVoiceHud,
                                    onApplySwap = viewModel::applyShoulderSwap,
                                    onSendMessage = viewModel::sendChatMessage
                                )
                            }

                            AppTab.NUTRITION -> {
                                NutritionScreen(
                                    state = state,
                                    onAddWater = viewModel::addWater250,
                                    onLogRecipe = viewModel::logRecipe,
                                    onFactQueryChange = viewModel::setFactQuery,
                                    onSelectFactCategory = viewModel::setFactCategoryFilter,
                                    onSelectNutrientGroup = viewModel::setNutrientFilter
                                )
                            }

                            AppTab.GEAR -> {
                                GearScreen(
                                    state = state,
                                    onAddToCart = viewModel::addToCart,
                                    onClearCart = viewModel::clearCart
                                )
                            }
                        }
                    }
                }
            }

            FloatingBottomDock(
                currentTab = state.tab,
                language = state.language,
                cartCount = state.cartIndices.size,
                onSelectTab = viewModel::selectTab,
                modifier = Modifier.align(Alignment.BottomCenter)
            )

            // Toast HUD Pill
            AnimatedVisibility(
                visible = state.toastMessage != null,
                enter = fadeIn() + slideInVertically { it / 2 },
                exit = fadeOut() + slideOutVertically { it / 2 },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 96.dp, start = 16.dp, end = 16.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xF2121418),
                    border = BorderStroke(1.dp, NeonLime.copy(alpha = 0.55f)),
                    shadowElevation = 12.dp
                ) {
                    Text(
                        text = state.toastMessage.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = NeonLime,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                    )
                }
            }

            // Workout Detail Bottom Sheet
            val selectedWo = state.selectedWorkoutId?.let { ExerciseData.workoutsById[it] }
            if (selectedWo != null) {
                WorkoutDetailBottomSheet(
                    workout = selectedWo,
                    resolvedExercises = viewModel.resolveWorkoutExercises(selectedWo, state),
                    language = state.language,
                    onDismiss = { viewModel.openWorkout(null) },
                    onOpenExerciseGuide = { exId -> viewModel.openExerciseGuide(exId) },
                    onStartSession = viewModel::startWorkoutSession
                )
            }

            // Exercise Guide Bottom Sheet
            val selectedEx = state.selectedExerciseId?.let { ExerciseData.exercisesById[it] }
            if (selectedEx != null) {
                ExerciseGuideBottomSheet(
                    exercise = selectedEx,
                    language = state.language,
                    onDismiss = { viewModel.openExerciseGuide(null) }
                )
            }

            // Full-Screen Guided Live Session
            val activeSession = state.activeSession
            if (activeSession != null) {
                LiveSessionOverlay(
                    session = activeSession,
                    language = state.language,
                    onRepCompleted = viewModel::onSessionRepCompleted,
                    onCompleteSet = viewModel::finishCurrentSessionSet,
                    onSkipRest = viewModel::skipSessionRest,
                    onTogglePause = viewModel::toggleSessionPause,
                    onEndSession = viewModel::endWorkoutSession
                )
            }
        }
    }
}
