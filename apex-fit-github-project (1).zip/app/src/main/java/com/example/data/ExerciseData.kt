package com.example.data

import com.example.model.BiList
import com.example.model.BiText
import com.example.model.Equipment
import com.example.model.Exercise
import com.example.model.ExerciseCategory
import com.example.model.PoseType
import com.example.model.TrainingProgram
import com.example.model.WorkoutExerciseSpec
import com.example.model.WorkoutLevel
import com.example.model.WorkoutPlan

data class PoseFrame(
    val h: Pair<Float, Float>,
    val s: Pair<Float, Float>,
    val e: Pair<Float, Float>,
    val w: Pair<Float, Float>,
    val hp: Pair<Float, Float>,
    val k: Pair<Float, Float>,
    val a: Pair<Float, Float>
) {
    fun joint(key: String): Pair<Float, Float> = when (key) {
        "h" -> h; "s" -> s; "e" -> e; "w" -> w; "hp" -> hp; "k" -> k; else -> a
    }
}

data class MuscleAnchor(
    val muscleKey: String,
    val jointA: String,
    val jointB: String,
    val t: Float,
    val radius: Float
)

object ExerciseData {

    val poseFrames: Map<PoseType, List<PoseFrame>> = mapOf(
        PoseType.PUSHUP to listOf(
            PoseFrame(38f to 88f, 62f to 100f, 62f to 135f, 62f to 172f, 125f to 118f, 160f to 142f, 186f to 170f),
            PoseFrame(36f to 122f, 62f to 130f, 92f to 150f, 62f to 172f, 125f to 132f, 160f to 150f, 186f to 170f)
        ),
        PoseType.SQUAT to listOf(
            PoseFrame(100f to 28f, 100f to 55f, 118f to 70f, 140f to 58f, 100f to 108f, 104f to 140f, 102f to 172f),
            PoseFrame(118f to 62f, 116f to 80f, 134f to 88f, 150f to 80f, 120f to 124f, 138f to 140f, 104f to 172f)
        ),
        PoseType.PULLUP to listOf(
            PoseFrame(108f to 88f, 100f to 80f, 97f to 48f, 96f to 18f, 102f to 122f, 106f to 152f, 104f to 182f),
            PoseFrame(108f to 8f, 100f to 40f, 80f to 30f, 96f to 18f, 102f to 88f, 106f to 118f, 104f to 148f)
        ),
        PoseType.PLANK to listOf(
            PoseFrame(40f to 100f, 62f to 105f, 68f to 140f, 44f to 160f, 138f to 108f, 168f to 118f, 190f to 128f),
            PoseFrame(40f to 100f, 62f to 104f, 68f to 140f, 44f to 160f, 138f to 104f, 168f to 114f, 190f to 124f)
        ),
        PoseType.LUNGE to listOf(
            PoseFrame(100f to 30f, 100f to 57f, 118f to 72f, 138f to 64f, 100f to 108f, 104f to 142f, 100f to 182f),
            PoseFrame(100f to 50f, 100f to 77f, 118f to 92f, 138f to 84f, 100f to 118f, 126f to 150f, 112f to 182f)
        ),
        PoseType.PIKE to listOf(
            PoseFrame(48f to 112f, 70f to 100f, 66f to 140f, 72f to 176f, 124f to 58f, 156f to 118f, 184f to 176f),
            PoseFrame(60f to 130f, 80f to 118f, 84f to 152f, 72f to 176f, 124f to 58f, 156f to 118f, 184f to 176f)
        ),
        PoseType.RAISE to listOf(
            PoseFrame(30f to 168f, 60f to 170f, 50f to 178f, 36f to 180f, 110f to 172f, 150f to 172f, 186f to 172f),
            PoseFrame(30f to 168f, 60f to 170f, 50f to 178f, 36f to 180f, 110f to 172f, 140f to 110f, 160f to 60f)
        ),
        PoseType.SIT to listOf(
            PoseFrame(100f to 44f, 100f to 70f, 118f to 92f, 118f to 116f, 100f to 130f, 150f to 140f, 160f to 182f),
            PoseFrame(100f to 44f, 100f to 70f, 82f to 92f, 82f to 116f, 100f to 130f, 150f to 140f, 160f to 182f)
        )
    )

    val muscleAnchors: Map<PoseType, List<MuscleAnchor>> = mapOf(
        PoseType.PUSHUP to listOf(MuscleAnchor("chest", "s", "h", 0.3f, 13f), MuscleAnchor("delts", "s", "e", 0.2f, 9f), MuscleAnchor("core", "s", "hp", 0.55f, 9f), MuscleAnchor("triceps", "e", "w", 0.4f, 6f)),
        PoseType.SQUAT to listOf(MuscleAnchor("quads", "hp", "k", 0.5f, 12f), MuscleAnchor("glutes", "hp", "k", 0.05f, 10f), MuscleAnchor("core", "s", "hp", 0.5f, 9f), MuscleAnchor("hams", "hp", "k", 0.8f, 7f)),
        PoseType.PULLUP to listOf(MuscleAnchor("lats", "s", "hp", 0.35f, 13f), MuscleAnchor("biceps", "e", "s", 0.5f, 8f), MuscleAnchor("forearms", "w", "e", 0.5f, 6f), MuscleAnchor("core", "s", "hp", 0.7f, 8f)),
        PoseType.PLANK to listOf(MuscleAnchor("core", "s", "hp", 0.5f, 12f), MuscleAnchor("delts", "s", "e", 0.4f, 9f), MuscleAnchor("glutes", "hp", "a", 0.1f, 9f)),
        PoseType.LUNGE to listOf(MuscleAnchor("quads", "hp", "k", 0.5f, 12f), MuscleAnchor("glutes", "hp", "k", 0.05f, 10f), MuscleAnchor("hams", "hp", "k", 0.9f, 6f)),
        PoseType.PIKE to listOf(MuscleAnchor("delts", "s", "e", 0.3f, 11f), MuscleAnchor("triceps", "e", "w", 0.5f, 6f), MuscleAnchor("core", "s", "hp", 0.5f, 9f), MuscleAnchor("hams", "hp", "a", 0.5f, 8f)),
        PoseType.RAISE to listOf(MuscleAnchor("core", "s", "hp", 0.5f, 11f), MuscleAnchor("quads", "hp", "k", 0.5f, 9f), MuscleAnchor("glutes", "hp", "k", 0.1f, 9f)),
        PoseType.SIT to listOf(MuscleAnchor("core", "s", "hp", 0.5f, 12f), MuscleAnchor("obliques", "s", "hp", 0.85f, 7f))
    )

    val exercises: List<Exercise> = listOf(
        Exercise(
            "pushup", ExerciseCategory.CHEST, PoseType.PUSHUP,
            BiText("Standard Push-Up", "ضغط الأرض العادي"),
            listOf("chest", "triceps"), listOf("delts", "core"), emptyList(), null,
            BiList(
                listOf("Hands under shoulders, body in a straight line from head to heels, core braced.", "Lower the chest until elbows reach about 90°, then press back to full lockout.", "Inhale on the way down, exhale on the press. Keep the neck long."),
                listOf("ضع اليدين تحت الكتفين، واجعل الجسم خطاً مستقيماً من الرأس إلى الكعبين مع شدّ البطن.", "أنزل الصدر حتى يصل الكوعان إلى نحو 90 درجة، ثم ادفع للأعلى حتى تفرد الذراعين تماماً.", "شهيق عند النزول وزفير عند الدفع، واحافظ على استطالة الرقبة.")
            ),
            BiList(
                listOf("Sagging hips or flared elbows put stress on the shoulder joint.", "Partial reps: go down until the chest nearly touches the floor."),
                listOf("ترهّل الحوض أو فتح الكوعين للخارج يضغط مفصل الكتف.", "التكرارات الجزئية: انزل حتى يقترب الصدر من الأرض.")
            ),
            BiList(
                listOf("Incline push-ups on a sturdy table, 3 × 10", "Standard push-ups, 4 × 15, controlled tempo", "Slow 4-second descent with a 2-second pause at the bottom"),
                listOf("ضغط مائل على طاولة متينة، 3 × 10", "ضغط عادي، 4 × 15 بإيقاع مضبوط", "نزول بطيء 4 ثوانٍ مع توقف ثانيتين في الأسفل")
            )
        ),
        Exercise(
            "diamond", ExerciseCategory.CHEST, PoseType.PUSHUP,
            BiText("Diamond Push-Up", "ضغط الماسة"),
            listOf("triceps", "chest"), listOf("delts"), emptyList(), "pushup",
            BiList(
                listOf("Hands together under the chest, thumbs and index fingers forming a diamond.", "Lower the chest toward the hands, keeping elbows close to the ribs.", "Exhale as you press. Keep the hips level throughout."),
                listOf("ضع اليدين معاً تحت الصدر، والإبهام والسبابة يشكلان ماسة.", "أنزل الصدر نحو اليدين مع إبقاء الكوعين قريبين من الأضلاع.", "زفير عند الدفع، وحافظ على استواء الحوض طوال الحركة.")
            ),
            BiList(
                listOf("Elbows flaring outward shifts the load to the shoulders.", "Hands placed too far forward strains the wrists."),
                listOf("فتح الكوعين للخارج ينقل الحمل إلى الأكتاف.", "وضع اليدين بعيداً للأمام يجهد الرسغين.")
            ),
            BiList(
                listOf("Knees-down diamond push-ups, 3 × 8", "Full diamond push-ups, 4 × 12", "Diamond push-ups with feet elevated on a chair"),
                listOf("ضغط الماسة على الركبتين، 3 × 8", "ضغط الماسة كامل، 4 × 12", "ضغط الماسة مع رفع القدمين على كرسي")
            )
        ),
        Exercise(
            "decline", ExerciseCategory.CHEST, PoseType.PUSHUP,
            BiText("Decline Push-Up", "ضغط الانحدار"),
            listOf("chest", "delts"), listOf("triceps"), listOf(Equipment.CHAIR), "pushup",
            BiList(
                listOf("Feet elevated on a chair or bench, hands on the floor shoulder-width apart.", "Lower the chest to just above the floor, keeping the body in one rigid line.", "Inhale down, exhale up. Squeeze glutes to keep the hips from sagging."),
                listOf("ارفع القدمين على كرسي أو مقعد، واليدين على الأرض بعرض الكتفين.", "أنزل الصدر حتى يقترب من الأرض، مع جسم مشدود كخط واحد.", "شهيق عند النزول وزفير عند الصعود، واشدّ الأرداف لمنع ترهّل الحوض.")
            ),
            BiList(
                listOf("Hips sagging, which turns the rep into a lower back exercise.", "Flaring elbows; keep them at about 45°."),
                listOf("ترهّل الحوض فيتحول التمرين إلى ضغط على أسفل الظهر.", "فتح الكوعين؛ اجعلهما بزاوية 45° تقريباً.")
            ),
            BiList(
                listOf("Low-height elevation, 3 × 10", "Chair elevation, 4 × 12", "Higher elevation with a 2-second pause"),
                listOf("ارتفاع منخفض للقدمين، 3 × 10", "رفع القدمين على كرسي، 4 × 12", "ارتفاع أعلى مع توقف ثانيتين")
            )
        ),
        Exercise(
            "archer", ExerciseCategory.CHEST, PoseType.PUSHUP,
            BiText("Archer Push-Up", "ضغط القوس"),
            listOf("chest"), listOf("triceps", "core"), emptyList(), "pushup",
            BiList(
                listOf("Wide hand position, one arm straight out to the side as the pivot.", "Shift weight toward the bent-arm side until the chest nearly touches the hand.", "Push back to the start, then switch sides with control."),
                listOf("ضع اليدين بعيدتين، وامدد ذراعاً واحدة للجانب كمحور للحركة.", "انقل الوزن نحو الجانب المثني حتى يقترب الصدر من اليد.", "ادفع للعودة إلى البداية، ثم بدّل الجانب بتحكّم.")
            ),
            BiList(
                listOf("Hips rotating instead of staying square.", "Rushing the transfer of weight."),
                listOf("دوران الحوض بدلاً من بقائه مستوياً.", "التسرّع في نقل الوزن بين الجانبين.")
            ),
            BiList(
                listOf("Archer push-up with hands on a table, 3 × 6 each side", "Floor archer push-ups, 3 × 8 each side", "Slow archer with a 2-second hold at the bottom"),
                listOf("ضغط القوس واليدان على طاولة، 3 × 6 لكل جانب", "ضغط القوس على الأرض، 3 × 8 لكل جانب", "ضغط القوس البطيء مع توقف ثانيتين في الأسفل")
            )
        ),
        Exercise(
            "pseudo", ExerciseCategory.CHEST, PoseType.PUSHUP,
            BiText("Pseudo Planche Push-Up", "ضغط البلانش الكاذب"),
            listOf("chest", "delts"), listOf("core", "triceps"), emptyList(), "decline",
            BiList(
                listOf("Hands turned slightly back, shoulders forward past the wrists, body leaning 10°.", "Lower with scapulae depressed, keeping the elbows tucked near the body.", "Press up without shrugging the shoulders. Exhale on the press."),
                listOf("أدر اليدين قليلاً للخلف، وقدّم الكتفين أمام الرسغين، مع ميل الجسم 10°.", "أنزل مع خفض لوح الكتف وإبقاء الكوعين قريبين من الجسم.", "ادفع للأعلى دون رفع الكتفين. زفير عند الدفع.")
            ),
            BiList(
                listOf("Shrugging the shoulders toward the ears.", "Letting the hips drop; keep the body rigid."),
                listOf("رفع الكتفين نحو الأذنين.", "ترك الحوض ينخفض؛ حافظ على صلابة الجسم.")
            ),
            BiList(
                listOf("Lean-forward push-ups with hands on a table, 3 × 8", "Pseudo planche push-ups, 4 × 8", "Pseudo planche with a 3-second hold at the bottom"),
                listOf("ضغط مع الميل للأمام واليدان على طاولة، 3 × 8", "ضغط البلانش الكاذب، 4 × 8", "البلانش الكاذب مع توقف 3 ثوانٍ في الأسفل")
            )
        ),
        Exercise(
            "chair-dip", ExerciseCategory.CHEST, PoseType.PUSHUP,
            BiText("Chair Dips", "تمرين الغطس على الكرسي"),
            listOf("triceps", "chest"), listOf("delts"), listOf(Equipment.CHAIR), "diamond",
            BiList(
                listOf("Hands on the edge of a sturdy chair, fingers forward, legs extended or bent.", "Lower until the upper arms are parallel to the floor, elbows pointing back.", "Press up to lockout. Keep the shoulders away from the ears."),
                listOf("ضع اليدين على حافة كرسي متين، والأصابع للأمام، والساقان ممدودتان أو مثنيتان.", "أنزل حتى تصبح العضدان موازيتين للأرض مع توجيه الكوعين للخلف.", "ادفع للأعلى حتى تفرد الذراعين، وأبعد الكتفين عن الأذنين.")
            ),
            BiList(
                listOf("Going too deep and stressing the front of the shoulder.", "Chair sliding; place it against a wall."),
                listOf("النزول بعمق زائد فيجهد مقدمة الكتف.", "انزلاق الكرسي؛ ضعه مقابل الحائط.")
            ),
            BiList(
                listOf("Bent-knee dips, 3 × 8", "Straight-leg dips, 4 × 12", "Dips with feet elevated on a second chair"),
                listOf("غطس بالركبتين مثنيتين، 3 × 8", "غطس بالساقين ممدودتين، 4 × 12", "غطس مع رفع القدمين على كرسي ثانٍ")
            )
        ),
        Exercise(
            "inv-row", ExerciseCategory.BACK, PoseType.PULLUP,
            BiText("Table / Doorframe Inverted Row", "السحب المقلوب على الطاولة أو إطار الباب"),
            listOf("lats", "biceps"), listOf("traps", "forearms"), listOf(Equipment.DOOR), "superman",
            BiList(
                listOf("Lie under a sturdy table, grip the edge, body straight, heels on the floor.", "Pull the chest to the edge by driving the elbows back and squeezing the shoulder blades.", "Exhale on the pull, lower slowly with a 2-second eccentric."),
                listOf("استلقِ أسفل طاولة متينة، وامسك الحافة، واجعل الجسم مستقيماً والكعبين على الأرض.", "اسحب الصدر نحو الحافة بدفع الكوعين للخلف وضم لوحي الكتف.", "زفير عند السحب، وانزل ببطء بعد 2 ثانية.")
            ),
            BiList(
                listOf("Hips sagging; keep a straight line.", "Not using a full range of motion."),
                listOf("ترهّل الحوض؛ حافظ على خط مستقيم.", "عدم استخدام المدى الكامل للحركة.")
            ),
            BiList(
                listOf("Feet bent close to the body, 3 × 8", "Straight body, 4 × 12", "Pause 2 seconds at the top, 4 × 10"),
                listOf("القدمان مثنيتان قريباً من الجسم، 3 × 8", "الجسم مستقيم، 4 × 12", "توقف ثانيتين في الأعلى، 4 × 10")
            )
        ),
        Exercise(
            "superman", ExerciseCategory.BACK, PoseType.PLANK,
            BiText("Superman Pull", "سحب السوبرمان"),
            listOf("back", "glutes"), listOf("traps"), emptyList(), null,
            BiList(
                listOf("Lie face down, arms extended overhead, legs straight.", "Lift the chest, arms and legs off the floor, then pull the arms down toward the hips.", "Exhale on the lift, hold briefly, and lower with control."),
                listOf("استلقِ على بطنك والذراعان ممدودتان فوق الرأس والساقان مستقيمتان.", "ارفع الصدر والذراعين والساقين عن الأرض، ثم اسحب الذراعين نحو الوركين.", "زفير عند الرفع، وثبّت لحظة، ثم انزل بتحكّم.")
            ),
            BiList(
                listOf("Neck hyperextension; look at the floor.", "Lifting too high, which strains the lower back."),
                listOf("فرط مد الرقبة؛ انظر إلى الأرض.", "الرفع العالي زيادةً، فيجهد أسفل الظهر.")
            ),
            BiList(
                listOf("Arms only, 3 × 10", "Arms and chest lift, 3 × 12", "Full superman pulls with 3-second hold, 4 × 10"),
                listOf("الذراعان فقط، 3 × 10", "الذراعان مع رفع الصدر، 3 × 12", "سحب السوبرمان كامل مع ثبات 3 ثوانٍ، 4 × 10")
            )
        ),
        Exercise(
            "towel-row", ExerciseCategory.BACK, PoseType.PULLUP,
            BiText("Towel Row", "السحب بالمنشفة"),
            listOf("lats", "biceps"), listOf("forearms"), listOf(Equipment.TOWEL), "superman",
            BiList(
                listOf("Loop a towel around a sturdy door handle or pole and grip both ends.", "Lean back with straight arms, then pull the chest toward the handle.", "Exhale on the pull and control the return."),
                listOf("لُفّ منشفة حول مقبض باب متين أو عمود وأمسك طرفيها.", "ميّل الجسم للخلف والذراعان ممدودتان، ثم اسحب الصدر نحو المقبض.", "زفير عند السحب، وتحكّم في العودة.")
            ),
            BiList(
                listOf("Towel slipping; test the anchor first.", "Shrugging the shoulders during the pull."),
                listOf("انزلاق المنشفة؛ اختبر التثبيت أولاً.", "رفع الكتفين أثناء السحب.")
            ),
            BiList(
                listOf("Feet close to the anchor, 3 × 10", "Feet further out, 4 × 12", "Single-arm towel row, 3 × 10 each side"),
                listOf("القدمان قريبتان من نقطة التثبيت، 3 × 10", "القدمان أبعد، 4 × 12", "سحب بذراع واحدة بالمنشفة، 3 × 10 لكل جانب")
            )
        ),
        Exercise(
            "pullup", ExerciseCategory.BACK, PoseType.PULLUP,
            BiText("Pull-Up / Chin-Up", "العقلة / العقلة بالكف المواجه"),
            listOf("lats", "biceps"), listOf("forearms", "core"), listOf(Equipment.BAR), "towel-row",
            BiList(
                listOf("Hang from the bar with a shoulder-width grip (overhand for pull-ups, underhand for chin-ups).", "Pull until the chin clears the bar, driving the elbows down and back.", "Exhale on the pull and lower to a full dead hang."),
                listOf("تعلّق بالعارضة بقبضة بعرض الكتفين (كف للأسفل للعقلة، أو كف للأعلى للعقلة بالكف المواجه).", "اسحب حتى يتجاوز الذقن العارضة، مع دفع الكوعين للأسفل والخلف.", "زفير عند السحب، وانزل إلى تعليق كامل.")
            ),
            BiList(
                listOf("Swinging or kipping instead of a strict pull.", "Stopping short of a full dead hang."),
                listOf("التأرجح أو الاندفاع بدل السحب المضبوط.", "التوقف قبل التعلّق الكامل.")
            ),
            BiList(
                listOf("Negative pull-ups: jump up, lower for 4 seconds, 3 × 4", "Full pull-ups, 4 × 6", "Pull-ups with a 2-second pause at the top, 4 × 8"),
                listOf("عقلة سالبة: اقفز للأعلى وانزل 4 ثوانٍ، 3 × 4", "عقلة كاملة، 4 × 6", "عقلة مع توقف ثانيتين في الأعلى، 4 × 8")
            )
        ),
        Exercise(
            "iso-back", ExerciseCategory.BACK, PoseType.PLANK,
            BiText("Isometric Back Hold", "ثبات الظهر المتساوي القياس"),
            listOf("back", "traps"), listOf("glutes"), emptyList(), null,
            BiList(
                listOf("Lie face down, forehead on the floor, arms by your sides with palms facing up.", "Lift the chest and legs slightly and hold, squeezing the shoulder blades.", "Breathe steadily through the nose during the hold."),
                listOf("استلقِ على بطنك وجبهتك على الأرض، والذراعان بجانبك والكفان للأعلى.", "ارفع الصدر والساقين قليلاً وثبّت، مع ضم لوحي الكتف.", "تنفس بثبات من الأنف طوال الثبات.")
            ),
            BiList(
                listOf("Holding breath during the hold.", "Pushing the neck up instead of lifting from the upper back."),
                listOf("حبس النفس أثناء الثبات.", "رفع الرقبة بدلاً من الرفع من أعلى الظهر.")
            ),
            BiList(
                listOf("10-second holds, 3 rounds", "30-second holds, 3 rounds", "45-second holds with arm circles"),
                listOf("ثبات 10 ثوانٍ، 3 جولات", "ثبات 30 ثانية، 3 جولات", "ثبات 45 ثانية مع دوائر بالذراعين")
            )
        ),
        Exercise(
            "pike", ExerciseCategory.SHOULDERS, PoseType.PIKE,
            BiText("Pike Push-Up", "ضغط الباي"),
            listOf("delts", "triceps"), listOf("core"), emptyList(), null,
            BiList(
                listOf("Start in an inverted V: hips high, hands shoulder-width apart, heels toward the floor.", "Bend the elbows and lower the head toward the floor between the hands.", "Press back up to the inverted V. Exhale on the press."),
                listOf("ابدأ بشكل V مقلوب: الحوض مرتفع، واليدان بعرض الكتفين، والكعبان نحو الأرض.", "ثنِ الكوعين وأنزل الرأس نحو الأرض بين اليدين.", "ادفع للعودة إلى شكل V المقلوب. زفير عند الدفع.")
            ),
            BiList(
                listOf("Bending the knees to make it easier, which turns it into a different move.", "Head landing too far forward."),
                listOf("ثني الركبتين لتسهيل الحركة، فتتحول إلى تمرين مختلف.", "وصول الرأس بعيداً للأمام.")
            ),
            BiList(
                listOf("Pike hold with bent elbows, 3 × 8", "Pike push-ups, 4 × 10", "Elevated pike push-ups, 4 × 8"),
                listOf("ثبات الباي مع ثني الكوعين، 3 × 8", "ضغط الباي، 4 × 10", "ضغط الباي مع رفع القدمين، 4 × 8")
            )
        ),
        Exercise(
            "pike-el", ExerciseCategory.SHOULDERS, PoseType.PIKE,
            BiText("Elevated Pike Push-Up", "ضغط الباي مع رفع القدمين"),
            listOf("delts", "triceps"), listOf("core"), listOf(Equipment.CHAIR), "pike",
            BiList(
                listOf("Feet on a chair, hands on the floor in an inverted V.", "Lower the head toward the floor between the hands, keeping the hips stacked over the shoulders.", "Press up with control. Exhale on the press."),
                listOf("ضع القدمين على كرسي، واليدان على الأرض بشكل V مقلوب.", "أنزل الرأس نحو الأرض بين اليدين، مع بقاء الحوض فوق الكتفين.", "ادفع للأعلى بتحكّم. زفير عند الدفع.")
            ),
            BiList(
                listOf("Chair sliding; secure it against a wall.", "Dropping the hips in the middle of the rep."),
                listOf("انزلاق الكرسي؛ ثبّته مقابل الحائط.", "هبوط الحوض في منتصف التكرار.")
            ),
            BiList(
                listOf("Low chair height, 3 × 8", "Chair height, 4 × 10", "Higher surface with a 2-second pause"),
                listOf("ارتفاع منخفض للكرسي، 3 × 8", "ارتفاع الكرسي المعتاد، 4 × 10", "سطح أعلى مع توقف ثانيتين")
            )
        ),
        Exercise(
            "wall-hspu", ExerciseCategory.SHOULDERS, PoseType.PIKE,
            BiText("Wall Handstand Push-Up", "ضغط الوقوف على اليدين مقابل الحائط"),
            listOf("delts", "triceps"), listOf("core", "traps"), emptyList(), "pike-el",
            BiList(
                listOf("Kick up into a handstand with your back near the wall, hands about 30 cm from it.", "Lower the head toward the floor until it lightly touches, then press back to lockout.", "Brace the glutes and ribs. Exhale on the press."),
                listOf("اصعد إلى الوقوف على اليدين مع ظهرك قريباً من الحائط، واليدان على بعد 30 سم منه.", "أنزل الرأس نحو الأرض حتى يلمسها بخفة، ثم ادفع للأعلى حتى تفرد الذراعين.", "اشدّ الأرداف والأضلاع. زفير عند الدفع.")
            ),
            BiList(
                listOf("Arching the lower back; squeeze the glutes.", "Kicking up with too much force and losing balance."),
                listOf("تقوّس أسفل الظهر؛ اشدّ الأرداف.", "الصعود بقوة زائدة فتفقد التوازن.")
            ),
            BiList(
                listOf("Wall handstand hold, 3 × 20 seconds", "Partial wall push-ups, 3 × 5", "Full wall handstand push-ups, 4 × 5"),
                listOf("ثبات الوقوف على اليدين مقابل الحائط، 3 × 20 ثانية", "ضغط جزئي مقابل الحائط، 3 × 5", "ضغط الوقوف على اليدين كامل مقابل الحائط، 4 × 5")
            )
        ),
        Exercise(
            "wall-hold", ExerciseCategory.SHOULDERS, PoseType.PIKE,
            BiText("Handstand Wall Hold", "ثبات الوقوف على اليدين مقابل الحائط"),
            listOf("delts", "core"), listOf("triceps"), emptyList(), "pike",
            BiList(
                listOf("Kick up with your back near the wall, hands shoulder-width apart.", "Stack wrists under shoulders and squeeze the glutes and ribs.", "Breathe slowly; hold without arching the lower back."),
                listOf("اصعد مع ظهرك قريباً من الحائط واليدان بعرض الكتفين.", "ضع الرسغين تحت الكتفين، واشدّ الأرداف والأضلاع.", "تنفس ببطء، وثبّت دون تقوّس أسفل الظهر.")
            ),
            BiList(
                listOf("Holding breath.", "Letting the shoulders shrug up."),
                listOf("حبس النفس.", "رفع الكتفين إلى الأعلى.")
            ),
            BiList(
                listOf("Hold 15 seconds, 3 rounds", "Hold 30 seconds, 3 rounds", "Hold 60 seconds, 3 rounds"),
                listOf("ثبات 15 ثانية، 3 جولات", "ثبات 30 ثانية، 3 جولات", "ثبات 60 ثانية، 3 جولات")
            )
        ),
        Exercise(
            "lat-walk", ExerciseCategory.SHOULDERS, PoseType.PLANK,
            BiText("Lateral Plank Walk", "مشي البلانك الجانبي"),
            listOf("delts", "obliques"), listOf("core"), emptyList(), null,
            BiList(
                listOf("Start in a high plank, hands under shoulders, body straight.", "Walk the hands sideways several steps, then walk the feet to meet them.", "Keep the hips level; move slowly and under control."),
                listOf("ابدأ بوضعية البلانك العالي، واليدان تحت الكتفين، والجسم مستقيم.", "امشِ بيديك جانباً عدة خطوات، ثم أحضر القدمين إليهما.", "حافظ على استواء الحوض؛ تحرّك ببطء وتحكّم.")
            ),
            BiList(
                listOf("Hips rocking side to side.", "Moving too fast to control the shoulders."),
                listOf("تأرجح الحوض يميناً ويساراً.", "الحركة السريعة التي تفقد التحكم في الكتفين.")
            ),
            BiList(
                listOf("Knees down, 3 × 8 each side", "High plank, 3 × 10 each side", "Slow tempo, 4 × 12 each side"),
                listOf("على الركبتين، 3 × 8 لكل جانب", "بلانك عالٍ، 3 × 10 لكل جانب", "إيقاع بطيء، 4 × 12 لكل جانب")
            )
        ),
        Exercise(
            "deficit-pike", ExerciseCategory.SHOULDERS, PoseType.PIKE,
            BiText("Deficit Pike Push-Up", "ضغط الباي مع فرق الارتفاع"),
            listOf("delts", "triceps"), listOf("chest", "core"), emptyList(), "pike",
            BiList(
                listOf("Place the hands on a lower surface (a stack of books) so the head drops below the hands.", "Lower the head past the hands, keeping elbows at about 45°.", "Press up, keeping the hips high. Exhale on the press."),
                listOf("ضع اليدين على سطح منخفض (كومة كتب) بحيث ينخفض الرأس عن مستوى اليدين.", "أنزل الرأس إلى ما دون مستوى اليدين مع إبقاء الكوعين بزاوية 45°.", "ادفع للأعلى مع إبقاء الحوض مرتفعاً. زفير عند الدفع.")
            ),
            BiList(
                listOf("Lowering the head too far and straining the neck.", "Letting the hips drop during the press."),
                listOf("إنزال الرأس بعمق زائد فيجهد الرقبة.", "ترك الحوض ينخفض أثناء الدفع.")
            ),
            BiList(
                listOf("Low deficit (one book), 3 × 8", "Medium deficit (two books), 4 × 10", "Large deficit with a 2-second pause, 4 × 8"),
                listOf("فرق بسيط (كتاب واحد)، 3 × 8", "فرق متوسط (كتابان)، 4 × 10", "فرق كبير مع توقف ثانيتين، 4 × 8")
            )
        ),
        Exercise(
            "squat", ExerciseCategory.LEGS, PoseType.SQUAT,
            BiText("Bodyweight Squat", "القرفصاء بوزن الجسم"),
            listOf("quads", "glutes"), listOf("hams", "core"), emptyList(), null,
            BiList(
                listOf("Feet shoulder-width apart, toes turned slightly out, arms forward for balance.", "Sit the hips back and down until the thighs are at least parallel to the floor.", "Drive up through the heels. Inhale down, exhale up."),
                listOf("ضع القدمين بعرض الكتفين مع فتح أصابع القدم قليلاً، والذراعان للأمام للتوازن.", "أرجع الحوض للخلف وللأسفل حتى تصبح الفخذان موازيتين للأرض على الأقل.", "ادفع بالكعبين للأعلى. شهيق عند النزول وزفير عند الصعود.")
            ),
            BiList(
                listOf("Knees collapsing inward.", "Heels lifting off the floor."),
                listOf("انهيار الركبتين إلى الداخل.", "رفع الكعبين عن الأرض.")
            ),
            BiList(
                listOf("Box squats to a chair, 3 × 15", "Full squats, 4 × 20", "Tempo squats, 3-second descent, 4 × 15"),
                listOf("قرفصاء مع الجلوس على كرسي، 3 × 15", "قرفصاء كاملة، 4 × 20", "قرفصاء بإيقاع، نزول 3 ثوانٍ، 4 × 15")
            )
        ),
        Exercise(
            "bulgarian", ExerciseCategory.LEGS, PoseType.LUNGE,
            BiText("Bulgarian Split Squat", "القرفصاء البلغارية"),
            listOf("quads", "glutes"), listOf("hams"), listOf(Equipment.CHAIR), "walk-lunge",
            BiList(
                listOf("Rear foot on a chair behind you, front foot about one stride forward.", "Lower the back knee toward the floor while keeping the torso upright.", "Drive through the front heel to stand. Switch sides after each set."),
                listOf("ضع قدمك الخلفية على كرسي خلفك، والقدم الأمامية على بُعد خطوة للأمام.", "أنزل الركبة الخلفية نحو الأرض مع إبقاء الجذع منتصباً.", "ادفع بكعب القدم الأمامية للوقوف. بدّل الجانب بعد كل مجموعة.")
            ),
            BiList(
                listOf("Front knee caving in.", "Leaning too far forward."),
                listOf("انهيار الركبة الأمامية إلى الداخل.", "الميل بعيداً للأمام.")
            ),
            BiList(
                listOf("Short stance, 3 × 8 each leg", "Standard stance, 3 × 10 each leg", "Pause at the bottom, 4 × 8 each leg"),
                listOf("خطوة قصيرة، 3 × 8 لكل ساق", "خطوة عادية، 3 × 10 لكل ساق", "توقف في الأسفل، 4 × 8 لكل ساق")
            )
        ),
        Exercise(
            "pistol", ExerciseCategory.LEGS, PoseType.SQUAT,
            BiText("Pistol Squat", "قرفصاء على ساق واحدة"),
            listOf("quads", "glutes"), listOf("core", "calves"), listOf(Equipment.DOOR), "squat",
            BiList(
                listOf("Stand on one leg, the other extended forward and held off the floor.", "Lower into a deep single-leg squat, keeping the heel down and the chest up.", "Stand back up with control. Hold a door frame for balance if needed."),
                listOf("قف على ساق واحدة والأخرى ممدودة للأمام ومعلّقة عن الأرض.", "أنزل إلى قرفصاء عميقة على ساق واحدة، مع بقاء الكعب على الأرض والصدر مرفوعاً.", "ارتفع للوقوف بتحكّم. استعن بإطار الباب للتوازن عند الحاجة.")
            ),
            BiList(
                listOf("Heel lifting off the floor.", "Rushing down and losing control."),
                listOf("رفع الكعب عن الأرض.", "النزول المتسرّع وفقدان التحكم.")
            ),
            BiList(
                listOf("Assisted pistol with a door frame, 3 × 5 each leg", "Box pistol, 3 × 6 each leg", "Full pistol squat, 4 × 5 each leg"),
                listOf("قرفصاء على ساق بمساعدة إطار الباب، 3 × 5 لكل ساق", "قرفصاء على ساق على صندوق، 3 × 6 لكل ساق", "قرفصاء على ساق كاملة، 4 × 5 لكل ساق")
            )
        ),
        Exercise(
            "jsq", ExerciseCategory.LEGS, PoseType.SQUAT,
            BiText("Jump Squat", "القرفصاء القافزة"),
            listOf("quads", "glutes"), listOf("calves", "core"), emptyList(), "squat",
            BiList(
                listOf("Start in a squat with feet shoulder-width apart and arms back.", "Explode upward, swinging the arms forward and fully extending the legs.", "Land softly with the knees bent and go straight into the next rep."),
                listOf("ابدأ في وضعية القرفصاء، والقدمان بعرض الكتفين، والذراعان للخلف.", "انفجر للأعلى مع تأرجح الذراعين للأمام ومد الساقين بالكامل.", "اهبط بنعومة والركبتان مثنيتان، وانتقل مباشرة للتكرار التالي.")
            ),
            BiList(
                listOf("Landing with straight knees.", "Not resetting depth between jumps."),
                listOf("الهبوط بركبتين ممدودتين.", "عدم العودة إلى العمق الكامل بين القفزات.")
            ),
            BiList(
                listOf("Squat jumps, 3 × 6", "Jump squats, 4 × 8", "Pause-squat jumps, 4 × 6"),
                listOf("قفز القرفصاء، 3 × 6", "القرفصاء القافزة، 4 × 8", "قفز القرفصاء مع توقف، 4 × 6")
            )
        ),
        Exercise(
            "walk-lunge", ExerciseCategory.LEGS, PoseType.LUNGE,
            BiText("Walking Lunge", "الاندفاع المتحرك"),
            listOf("quads", "glutes"), listOf("hams"), emptyList(), null,
            BiList(
                listOf("Stand tall, hands on the hips or on the chest.", "Step forward and lower the back knee toward the floor.", "Push off the front heel and bring the back foot forward into the next step."),
                listOf("قف منتصباً، واليدان على الوركين أو الصدر.", "تقدّم خطوة للأمام وأنزل الركبة الخلفية نحو الأرض.", "ادفع بكعب القدم الأمامية، وأحضر القدم الخلفية للخطوة التالية.")
            ),
            BiList(
                listOf("Front knee passing far beyond the toes.", "Torso leaning forward."),
                listOf("تجاوز الركبة الأمامية أصابع القدم بمسافة كبيرة.", "ميل الجذع للأمام.")
            ),
            BiList(
                listOf("Stationary lunges, 3 × 8 each leg", "Walking lunges, 3 × 12 each leg", "Walking lunges with a pause, 4 × 10 each leg"),
                listOf("اندفاع ثابت، 3 × 8 لكل ساق", "اندفاع متحرك، 3 × 12 لكل ساق", "اندفاع متحرك مع توقف، 4 × 10 لكل ساق")
            )
        ),
        Exercise(
            "bridge", ExerciseCategory.LEGS, PoseType.RAISE,
            BiText("Glute Bridge", "جسر الأرداف"),
            listOf("glutes", "hams"), listOf("core"), emptyList(), null,
            BiList(
                listOf("Lie on your back, knees bent, feet flat on the floor hip-width apart.", "Drive the hips up until the body forms a straight line from knees to shoulders.", "Squeeze the glutes at the top, then lower slowly. Exhale on the lift."),
                listOf("استلقِ على ظهرك والركبتان مثنيتان والقدمان مسطحتان بعرض الحوض.", "ارفع الحوض للأعلى حتى يصبح الجسم خطاً مستقيماً من الركبتين للكتفين.", "اشدّ الأرداف في الأعلى، ثم أنزل ببطء. زفير عند الرفع.")
            ),
            BiList(
                listOf("Pushing through the toes instead of the heels.", "Overarching the lower back at the top."),
                listOf("الدفع بأطراف الأصابع بدلاً من الكعبين.", "تقوّس أسفل الظهر في الأعلى.")
            ),
            BiList(
                listOf("Two-leg bridge, 3 × 15", "Single-leg bridge, 3 × 10 each leg", "Single-leg bridge with a 3-second hold, 4 × 8"),
                listOf("جسر على الساقين، 3 × 15", "جسر على ساق واحدة، 3 × 10 لكل ساق", "جسر على ساق مع ثبات 3 ثوانٍ، 4 × 8")
            )
        ),
        Exercise(
            "calf", ExerciseCategory.LEGS, PoseType.SQUAT,
            BiText("Single-Leg Calf Raise", "رفع السمانة على ساق واحدة"),
            listOf("calves"), listOf("core"), listOf(Equipment.CHAIR), null,
            BiList(
                listOf("Stand on one leg on the edge of a step, holding a wall for balance.", "Rise up onto the ball of the foot as high as possible.", "Lower the heel below the step level slowly for a full stretch."),
                listOf("قف على ساق واحدة على حافة درجة، واستند إلى الحائط للتوازن.", "ارتفع على مشط القدم قدر الإمكان.", "أنزل الكعب ببطء تحت مستوى الدرجة لتمطيط كامل.")
            ),
            BiList(
                listOf("Bouncing instead of controlled reps.", "Not using the full range."),
                listOf("القفز بدلاً من التكرار المضبوط.", "عدم استخدام المدى الكامل.")
            ),
            BiList(
                listOf("Two-leg calf raises, 3 × 20", "Single-leg calf raises, 3 × 15 each leg", "Single-leg, 3-second lowering, 4 × 12 each leg"),
                listOf("رفع السمانة على الساقين، 3 × 20", "رفع السمانة على ساق واحدة، 3 × 15 لكل ساق", "على ساق واحدة مع نزول 3 ثوانٍ، 4 × 12 لكل ساق")
            )
        ),
        Exercise(
            "hollow", ExerciseCategory.CORE, PoseType.PLANK,
            BiText("Hollow Body Hold", "ثبات الجسم المجوّف"),
            listOf("core"), listOf("quads"), emptyList(), null,
            BiList(
                listOf("Lie on your back, arms overhead, legs straight.", "Press the lower back into the floor and lift the shoulders and legs a few centimetres.", "Keep the body in a shallow banana shape and breathe steadily."),
                listOf("استلقِ على ظهرك والذراعان فوق الرأس والساقان مستقيمتان.", "اضغط أسفل الظهر على الأرض وارفع الكتفين والساقين بضعة سنتيمترات.", "حافظ على شكل الموزة الخفيف وتنفس بثبات.")
            ),
            BiList(
                listOf("Lower back arching off the floor.", "Holding breath."),
                listOf("تقوّس أسفل الظهر بعيداً عن الأرض.", "حبس النفس.")
            ),
            BiList(
                listOf("Tuck hold, 3 × 20 seconds", "Hollow hold with legs straight, 3 × 30 seconds", "Hollow hold with arms extended, 4 × 45 seconds"),
                listOf("ثبات مع ثني الركبتين، 3 × 20 ثانية", "ثبات مجوّف مع ساقين مستقيمتين، 3 × 30 ثانية", "ثبات مجوّف مع ذراعين ممدودتين، 4 × 45 ثانية")
            )
        ),
        Exercise(
            "plank-push", ExerciseCategory.CORE, PoseType.PUSHUP,
            BiText("Plank to Push-Up", "من البلانك إلى الضغط"),
            listOf("core", "chest"), listOf("delts", "triceps"), emptyList(), null,
            BiList(
                listOf("Start on the forearms in a plank, elbows under shoulders.", "Push up one arm at a time to a high plank, then lower back down to the forearms.", "Alternate the leading arm each rep and keep the hips still."),
                listOf("ابدأ على الساعدين في وضعية البلانك، والكوعان تحت الكتفين.", "ادفع بذراع واحدة في كل مرة إلى البلانك العالي، ثم عد للساعدين.", "بدّل الذراع الرائدة في كل تكرار، وابقِ الحوض ثابتاً.")
            ),
            BiList(
                listOf("Hips rocking side to side.", "Rushing and losing the plank."),
                listOf("تأرجح الحوض جانبياً.", "التسرّع وفقدان وضعية البلانك.")
            ),
            BiList(
                listOf("Knees down, 3 × 8", "Full plank to push-up, 3 × 10", "Slow tempo, 4 × 8"),
                listOf("على الركبتين، 3 × 8", "من البلانك إلى الضغط كامل، 3 × 10", "إيقاع بطيء، 4 × 8")
            )
        ),
        Exercise(
            "lsit", ExerciseCategory.CORE, PoseType.SIT,
            BiText("L-Sit Progression", "تدرّج وضعية L"),
            listOf("core", "quads"), listOf("delts", "triceps"), listOf(Equipment.CHAIR), "hollow",
            BiList(
                listOf("Hands on two chairs or parallettes, arms locked, shoulders pressed down.", "Lift the body until the legs are parallel to the floor or as high as you can.", "Keep the legs straight and exhale as you lift."),
                listOf("ضع اليدين على كرسيين أو على قاعدتين متوازيتين، والذراعان مقفولتان، والكتفان مضغوطان للأسفل.", "ارفع الجسم حتى تصبح الساقان موازيتين للأرض أو أعلى ما تستطيع.", "أبقِ الساقين مستقيمتين وزفر أثناء الرفع.")
            ),
            BiList(
                listOf("Shoulders shrugging up toward the ears.", "Bent knees without control."),
                listOf("رفع الكتفين نحو الأذنين.", "ثني الركبتين دون تحكم.")
            ),
            BiList(
                listOf("Tuck L-sit, hold 10 seconds", "Advanced tuck, hold 20 seconds", "One-leg L-sit, hold 15 seconds"),
                listOf("ثبات L بثني الركبتين، 10 ثوانٍ", "ثبات L متقدم بثني الركبتين، 20 ثانية", "ثبات L على ساق واحدة، 15 ثانية")
            )
        ),
        Exercise(
            "leg-raise", ExerciseCategory.CORE, PoseType.RAISE,
            BiText("Floor Leg Raise", "رفع الساقين من الأرض"),
            listOf("core"), listOf("quads"), emptyList(), null,
            BiList(
                listOf("Lie on your back, hands under the glutes for support, legs straight.", "Raise the legs to about 90° while keeping the lower back in contact with the floor.", "Lower slowly, stopping just above the floor without touching it."),
                listOf("استلقِ على ظهرك، واليدان تحت الأرداف للدعم، والساقان مستقيمتان.", "ارفع الساقين حتى 90 درجة تقريباً مع بقاء أسفل الظهر ملامساً للأرض.", "أنزل ببطء، وتوقف فوق الأرض دون أن تلامسها.")
            ),
            BiList(
                listOf("Lower back lifting off the floor.", "Dropping the legs too fast."),
                listOf("رفع أسفل الظهر عن الأرض.", "إنزال الساقين بسرعة زائدة.")
            ),
            BiList(
                listOf("Bent-knee raises, 3 × 12", "Straight-leg raises, 3 × 12", "Slow straight-leg raises, 4 × 10"),
                listOf("رفع الساقين مع ثنيهما، 3 × 12", "رفع الساقين ممدودتين، 3 × 12", "رفع الساقين الممدودتين ببطء، 4 × 10")
            )
        ),
        Exercise(
            "mtn", ExerciseCategory.CORE, PoseType.PLANK,
            BiText("Mountain Climbers", "متسلّق الجبال"),
            listOf("core"), listOf("delts", "quads"), emptyList(), null,
            BiList(
                listOf("Start in a high plank with hands under shoulders.", "Drive one knee toward the chest, then switch legs rapidly.", "Keep the hips low and the back flat."),
                listOf("ابدأ في وضعية البلانك العالي، واليدان تحت الكتفين.", "اسحب ركبة نحو الصدر، ثم بدّل الساقين بسرعة.", "أبقِ الحوض منخفضاً والظهر مستوياً.")
            ),
            BiList(
                listOf("Hips rising into a pike.", "Looking up instead of keeping the neck neutral."),
                listOf("ارتفاع الحوض فيتحول الوضع إلى باي.", "النظر للأعلى بدلاً من حفظ الرقبة محايدة.")
            ),
            BiList(
                listOf("Slow mountain climbers, 3 × 20", "Standard, 4 × 30 seconds", "Fast, 4 × 40 seconds"),
                listOf("متسلّق بطيء، 3 × 20", "عادي، 4 × 30 ثانية", "سريع، 4 × 40 ثانية")
            )
        ),
        Exercise(
            "russian", ExerciseCategory.CORE, PoseType.SIT,
            BiText("Russian Twist", "الدوران الروسي"),
            listOf("obliques", "core"), listOf("delts"), emptyList(), null,
            BiList(
                listOf("Sit with knees bent, lean back to about 45°, feet lifted or resting on the floor.", "Rotate the torso and hands side to side, touching the floor beside the hip.", "Keep the chest tall and rotate from the ribs, not just the arms."),
                listOf("اجلس وركبتاك مثنيتان، واتكئ للخلف بزاوية 45° تقريباً، والقدمان مرفوعتان أو على الأرض.", "أدر الجذع واليدين يميناً ويساراً، ولامس الأرض بجانب الورك.", "أبقِ الصدر مرفوعاً ودوّر من الأضلاع لا من الذراعين فقط.")
            ),
            BiList(
                listOf("Rounding the spine.", "Moving only the arms."),
                listOf("تقويس العمود الفقري.", "تحريك الذراعين فقط.")
            ),
            BiList(
                listOf("Feet on the floor, 3 × 16", "Feet lifted, 3 × 20", "Feet lifted with a slow pause on each side, 4 × 20"),
                listOf("القدمان على الأرض، 3 × 16", "القدمان مرفوعتان، 3 × 20", "القدمان مرفوعتان مع توقف بطيء على كل جانب، 4 × 20")
            )
        ),
        Exercise(
            "burpee", ExerciseCategory.HIIT, PoseType.PUSHUP,
            BiText("Burpee", "البربي"),
            listOf("core", "chest"), listOf("quads", "delts"), emptyList(), null,
            BiList(
                listOf("Start standing, drop into a squat with hands on the floor.", "Jump the feet back into a plank, do a push-up, jump the feet forward.", "Jump up with arms overhead. Land softly and repeat."),
                listOf("ابدأ واقفاً، ثم انزل إلى القرفصاء واليدان على الأرض.", "اقفز بالقدمين إلى البلانك، ونفّذ ضغطة، ثم اقفز بالقدمين للأمام.", "اقفز للأعلى والذراعان فوق الرأس. اهبط بنعومة وكرّر.")
            ),
            BiList(
                listOf("Sagging hips during the plank phase.", "Landing hard with straight knees."),
                listOf("ترهّل الحوض أثناء البلانك.", "الهبوط بقوة بركبتين ممدودتين.")
            ),
            BiList(
                listOf("Step-back burpees, 3 × 8", "Standard burpees, 4 × 10", "Burpee with a tuck jump, 4 × 8"),
                listOf("بربي مع خطوة للخلف، 3 × 8", "بربي عادي، 4 × 10", "بربي مع قفزة ثني، 4 × 8")
            )
        ),
        Exercise(
            "hi-knee", ExerciseCategory.HIIT, PoseType.SQUAT,
            BiText("High Knees", "الركض مع رفع الركبتين"),
            listOf("core", "quads"), listOf("calves"), emptyList(), null,
            BiList(
                listOf("Stand tall with feet hip-width apart.", "Run in place, driving each knee up to hip height or higher.", "Pump the arms and stay on the balls of the feet."),
                listOf("قف منتصباً والقدمان بعرض الحوض.", "اركض في المكان، وارفع كل ركبة إلى مستوى الحوض أو أعلى.", "حرّك الذراعين بقوة وابقَ على مشط القدمين.")
            ),
            BiList(
                listOf("Leaning back as the knees rise.", "Landing flat-footed and heavy."),
                listOf("الميل للخلف عند رفع الركبتين.", "الهبوط بكامل القدم بثقل.")
            ),
            BiList(
                listOf("Marching high knees, 3 × 30 seconds", "High knees, 4 × 30 seconds", "Fast high knees, 4 × 45 seconds"),
                listOf("رفع الركبتين بالمشي، 3 × 30 ثانية", "رفع الركبتين، 4 × 30 ثانية", "رفع الركبتين السريع، 4 × 45 ثانية")
            )
        ),
        Exercise(
            "jj", ExerciseCategory.HIIT, PoseType.SQUAT,
            BiText("Jumping Jacks", "القفز الجاكي"),
            listOf("full"), listOf("delts", "calves"), emptyList(), null,
            BiList(
                listOf("Stand with feet together and arms at your sides.", "Jump the feet wide while raising the arms overhead, then return.", "Keep a steady rhythm and land on the balls of the feet."),
                listOf("قف والقدمان متلاصقتان والذراعان بجانبك.", "افتح القدمين مع رفع الذراعين فوق الرأس، ثم ارجع.", "حافظ على إيقاع ثابت، واهبط على مشط القدمين.")
            ),
            BiList(
                listOf("Landing with locked knees.", "Tense shoulders during the arm raise."),
                listOf("الهبوط بركبتين مقفولتين.", "شدّ الكتفين أثناء رفع الذراعين.")
            ),
            BiList(
                listOf("Step jacks, 3 × 40 seconds", "Standard jacks, 3 × 40 seconds", "Fast jacks, 4 × 45 seconds"),
                listOf("جاكي بخطوات، 3 × 40 ثانية", "جاكي عادي، 3 × 40 ثانية", "جاكي سريع، 4 × 45 ثانية")
            )
        ),
        Exercise(
            "shadow", ExerciseCategory.HIIT, PoseType.SQUAT,
            BiText("Shadow Boxing", "الملاكمة الوهمية"),
            listOf("delts", "core"), listOf("triceps"), emptyList(), null,
            BiList(
                listOf("Stand in a boxer stance, knees soft, hands up by the face.", "Throw alternating jabs, crosses, and hooks while pivoting on the feet.", "Keep the guard up and breathe rhythmically."),
                listOf("قف بوضعية الملاكم، والركبتان مرنتان، واليدان مرفوعتان أمام الوجه.", "ألقِ لكمات متناوبة مستقيمة وعرضية مع الدوران على القدمين.", "أبقِ الحماية مرفوعة وتنفس بإيقاع.")
            ),
            BiList(
                listOf("Dropping the guard between punches.", "Locking the elbows at the end of every punch."),
                listOf("إنزال الحماية بين اللكمات.", "قفل الكوعين في نهاية كل لكمة.")
            ),
            BiList(
                listOf("Light shadow boxing, 3 × 1 minute", "Combinations, 4 × 1 minute", "Fast combinations with footwork, 5 × 1 minute"),
                listOf("ملاكمة وهمية خفيفة، 3 × دقيقة", "تركيبات لكمات، 4 × دقيقة", "تركيبات سريعة مع حركة القدمين، 5 × دقيقة")
            )
        ),
        Exercise(
            "tuck", ExerciseCategory.HIIT, PoseType.SQUAT,
            BiText("Explosive Tuck Jump", "القفزة المنفجرة مع ثني الركبتين"),
            listOf("quads", "glutes"), listOf("core", "calves"), emptyList(), "jsq",
            BiList(
                listOf("Start in a squat with arms back.", "Jump explosively and pull the knees toward the chest at the top.", "Land softly, reset into the squat, and repeat."),
                listOf("ابدأ في وضعية القرفصاء والذراعان للخلف.", "اقفز بانفجار واسحب الركبتين نحو الصدر في الأعلى.", "اهبط بنعومة، وعُد إلى القرفصاء وكرّر.")
            ),
            BiList(
                listOf("Not reaching full knee height.", "Landing with a jolt on the knees."),
                listOf("عدم الوصول إلى ارتفاع الركبتين الكامل.", "الهبوط بصدمة على الركبتين.")
            ),
            BiList(
                listOf("Squat jumps, 3 × 6", "Tuck jumps, 4 × 6", "Continuous tuck jumps, 4 × 8"),
                listOf("قفز القرفصاء، 3 × 6", "قفز مع ثني الركبتين، 4 × 6", "قفز مع ثني الركبتين متواصل، 4 × 8")
            )
        )
    )

    val exercisesById: Map<String, Exercise> = exercises.associateBy { it.id }

    val programs: List<TrainingProgram> = listOf(
        TrainingProgram("cal", BiText("Calisthenics Mastery", "إتقان الكالستنكس"), listOf("planche", "hs")),
        TrainingProgram("hyp", BiText("Hypertrophy Engine", "محرك الضخامة"), listOf("push", "back", "legs")),
        TrainingProgram("exp", BiText("Explosive Power", "القوة الانفجارية"), listOf("jump", "coreexp")),
        TrainingProgram("mob", BiText("Mobility & Deload", "المرونة والتخفيف"), listOf("mob1", "mob2"))
    )

    val workouts: List<WorkoutPlan> = listOf(
        WorkoutPlan(
            "planche", "cal",
            BiText("Explosive Planche & Calisthenics Mastery", "البلانش الانفجاري وإتقان الكالستنكس"),
            38, 420, WorkoutLevel.ADVANCED,
            BiText("Maintain scapular depression & fully locked elbows", "حافظ على خفض لوح الكتف وقفل الكوعين بالكامل"),
            mapOf("chest" to 92, "delts" to 84, "core" to 88),
            listOf(WorkoutExerciseSpec("pseudo", 4, 8, 2f, 90), WorkoutExerciseSpec("archer", 3, 6, 2f, 75), WorkoutExerciseSpec("decline", 4, 10, 2f, 60), WorkoutExerciseSpec("hollow", 3, 30, 3f, 45))
        ),
        WorkoutPlan(
            "hs", "cal",
            BiText("Handstand & Pike Strength", "قوة الوقوف على اليدين والباي"),
            36, 390, WorkoutLevel.ADVANCED,
            BiText("Brace glutes and ribs, keep the full range", "اشدّ الأرداف والأضلاع، وحافظ على المدى الكامل"),
            mapOf("delts" to 90, "triceps" to 84, "core" to 80),
            listOf(WorkoutExerciseSpec("wall-hspu", 4, 5, 2f, 120), WorkoutExerciseSpec("pike-el", 4, 8, 2f, 90), WorkoutExerciseSpec("pike", 3, 12, 2f, 60), WorkoutExerciseSpec("lat-walk", 3, 8, 2f, 40))
        ),
        WorkoutPlan(
            "push", "hyp",
            BiText("Upper Push Hypertrophy", "ضخامة الدفع العلوي"),
            45, 390, WorkoutLevel.INTERMEDIATE,
            BiText("Pause one second at the bottom of every rep", "توقف ثانية واحدة في الأسفل مع كل تكرار"),
            mapOf("chest" to 88, "triceps" to 86, "delts" to 80),
            listOf(WorkoutExerciseSpec("pushup", 4, 15, 2f, 60), WorkoutExerciseSpec("diamond", 4, 12, 2f, 60), WorkoutExerciseSpec("chair-dip", 4, 12, 2f, 75), WorkoutExerciseSpec("decline", 3, 10, 2f, 60))
        ),
        WorkoutPlan(
            "back", "hyp",
            BiText("Back & Pull Volume", "حجم الظهر والسحب"),
            40, 360, WorkoutLevel.INTERMEDIATE,
            BiText("Squeeze the shoulder blades before every pull", "اضمم لوحي الكتف قبل كل سحبة"),
            mapOf("lats" to 90, "biceps" to 80, "core" to 70),
            listOf(WorkoutExerciseSpec("inv-row", 4, 12, 2f, 60), WorkoutExerciseSpec("towel-row", 4, 12, 2f, 60), WorkoutExerciseSpec("pullup", 4, 8, 2f, 90), WorkoutExerciseSpec("iso-back", 3, 30, 3f, 45))
        ),
        WorkoutPlan(
            "legs", "hyp",
            BiText("Lower Body Hypertrophy", "ضخامة الجزء السفلي"),
            40, 400, WorkoutLevel.INTERMEDIATE,
            BiText("Knees track over toes, weight through the heel", "الركبتان تتبعان الأصابع، والوزن على الكعب"),
            mapOf("quads" to 90, "glutes" to 86, "hams" to 80),
            listOf(WorkoutExerciseSpec("squat", 4, 20, 1.5f, 45), WorkoutExerciseSpec("bulgarian", 3, 10, 2f, 75), WorkoutExerciseSpec("walk-lunge", 3, 16, 1.5f, 60), WorkoutExerciseSpec("bridge", 3, 15, 2f, 40), WorkoutExerciseSpec("calf", 3, 20, 1f, 30))
        ),
        WorkoutPlan(
            "jump", "exp",
            BiText("Jump Squat Circuit", "دائرة القفز بالقرفصاء"),
            30, 360, WorkoutLevel.ADVANCED,
            BiText("Land soft, absorb through hips and ankles", "اهبط بنعومة، وامتص الصدمة بالوركين والكاحلين"),
            mapOf("quads" to 90, "glutes" to 88, "core" to 76),
            listOf(WorkoutExerciseSpec("jsq", 5, 6, 1f, 90), WorkoutExerciseSpec("tuck", 4, 6, 1f, 90), WorkoutExerciseSpec("burpee", 4, 8, 1f, 75), WorkoutExerciseSpec("hi-knee", 3, 30, 1f, 45))
        ),
        WorkoutPlan(
            "coreexp", "exp",
            BiText("Core Power & Plyometrics", "قوة البطن والبليومتريك"),
            30, 340, WorkoutLevel.INTERMEDIATE,
            BiText("Maximal intent on every explosive rep", "نية قصوى في كل تكرار انفجاري"),
            mapOf("core" to 88, "delts" to 76, "triceps" to 70),
            listOf(WorkoutExerciseSpec("plank-push", 4, 8, 1f, 75), WorkoutExerciseSpec("leg-raise", 3, 12, 1.5f, 45), WorkoutExerciseSpec("mtn", 4, 30, 1f, 45), WorkoutExerciseSpec("shadow", 3, 40, 1f, 30))
        ),
        WorkoutPlan(
            "mob1", "mob",
            BiText("Thoracic & Shoulder Mobility Flow", "تدفّق مرونة الظهر العلوي والكتفين"),
            20, 120, WorkoutLevel.RECOVERY,
            BiText("Breathe into the ribs, never force end range", "تنفس في الأضلاع، ولا تفرض المدى الأقصى أبداً"),
            mapOf("core" to 78, "delts" to 72, "lats" to 70),
            listOf(WorkoutExerciseSpec("superman", 2, 10, 3f, 20), WorkoutExerciseSpec("lat-walk", 2, 8, 3f, 20), WorkoutExerciseSpec("iso-back", 2, 20, 3f, 30), WorkoutExerciseSpec("squat", 2, 8, 4f, 20))
        ),
        WorkoutPlan(
            "mob2", "mob",
            BiText("Hip & Hamstring Reset", "إعادة ضبط الوركين والخلفية"),
            25, 150, WorkoutLevel.RECOVERY,
            BiText("Hinge from the hips, neutral spine", "انحنِ من الوركين، والعمود الفقري محايد"),
            mapOf("hams" to 80, "glutes" to 76, "core" to 72),
            listOf(WorkoutExerciseSpec("bridge", 3, 12, 3f, 30), WorkoutExerciseSpec("squat", 3, 10, 3f, 30), WorkoutExerciseSpec("superman", 3, 10, 2f, 40))
        )
    )

    val workoutsById: Map<String, WorkoutPlan> = workouts.associateBy { it.id }
}
