package com.example.data

import com.example.model.BiText
import com.example.model.NutrientGroup
import com.example.model.NutrientGuideItem

object NutritionAcademyData {

    val nutrients: List<NutrientGuideItem> = listOf(
        // ================= MACRONUTRIENTS =================
        NutrientGuideItem(
            id = "protein",
            group = NutrientGroup.MACRO,
            name = BiText("Protein", "البروتين"),
            subtitle = BiText("Muscle Building & Tissue Repair", "بناء العضلات وإصلاح الأنسجة"),
            role = BiText(
                "Supplies essential amino acids (especially leucine) needed to repair muscle fibres after training, preserve lean mass, and support enzymes and immunity.",
                "يزوّد الجسم بالأحماض الأمينية الأساسية (وخاصة الليوسين) اللازمة لبناء وإصلاح الألياف العضلية بعد التمرين، والحفاظ على الكتلة العضلية، ودعم المناعة والإنزيمات."
            ),
            dailyTarget = BiText(
                "1.6 – 2.2 g per kg of body weight daily for active men.",
                "1.6 – 2.2 غ لكل كيلوغرام من وزن الجسم يومياً للرياضيين."
            ),
            foodSources = BiText(
                "Chicken breast, wild salmon, tuna, lean beef, eggs, Greek yogurt, cottage cheese, lentils, chickpeas, whey & casein.",
                "صدر الدجاج، السلمون، التونا، اللحم البقري قليل الدهن، البيض، الزبادي اليوناني، جبنة القريش، العدس، الحمص، والواي/الكازين."
            ),
            absorptionTip = BiText(
                "Distribute 25–45 g across 3–5 meals every 3–5 hours for optimal muscle protein synthesis.",
                "وزّع 25–45 غ من البروتين على 3–5 وجبات كل 3–5 ساعات لتحقيق أقصى تحفيز لبناء العضلات."
            )
        ),
        NutrientGuideItem(
            id = "carbs",
            group = NutrientGroup.MACRO,
            name = BiText("Carbohydrates", "الكربوهيدرات"),
            subtitle = BiText("Primary Kinetic & Brain Fuel", "الوقود الأساسي للعضلات والدماغ"),
            role = BiText(
                "Stored as muscle and liver glycogen to power high-intensity calisthenics, explosive reps, focus, and post-workout recovery.",
                "تُخزَّن كجلايكوجين في العضلات والكبد لتزويدك بالطاقة أثناء التمارين عالية الشدة والكالستنكس، وتدعم تركيز الدماغ وسرعة الاستشفاء."
            ),
            dailyTarget = BiText(
                "3 – 6 g per kg of body weight depending on training volume.",
                "3 – 6 غ لكل كيلوغرام من وزن الجسم حسب حجم التمرين اليومي."
            ),
            foodSources = BiText(
                "Complex: oats, quinoa, brown rice, sweet potatoes, whole-grain bread. Fast: bananas, dates, berries, honey.",
                "معقدة: الشوفان، الكينوا، الأرز البني، البطاطا الحلوة، خبز الحبوب الكاملة. سريعة: الموز، التمر، التوت، العسل."
            ),
            absorptionTip = BiText(
                "Use complex carbs 2–3 hours pre-workout for steady energy, and faster carbs post-workout with protein.",
                "تناول الكربوهيدرات المعقدة قبل التمرين بـ 2–3 ساعات لطاقة ثابتة، والسريعة بعد التمرين مع البروتين لتعويض الجلايكوجين."
            )
        ),
        NutrientGuideItem(
            id = "fats",
            group = NutrientGroup.MACRO,
            name = BiText("Healthy Fats & Omega-3", "الدهون الصحية وأوميغا 3"),
            subtitle = BiText("Hormones, Joints & Vitamin Absorption", "الهرمونات والمفاصل وامتصاص الفيتامينات"),
            role = BiText(
                "Essential for natural testosterone and steroid hormone production, cell membranes, brain health, joint comfort, and absorbing vitamins A, D, E, K.",
                "ضرورية لإنتاج الهرمونات الطبيعية مثل التستوستيرون، وصحة أغشية الخلايا والدماغ، وتخفيف التهاب المفاصل، وامتصاص فيتامينات A وD وE وK."
            ),
            dailyTarget = BiText(
                "0.7 – 1.1 g per kg of body weight (20–30% of daily calories).",
                "0.7 – 1.1 غ لكل كيلوغرام من الوزن (20–30% من السعرات اليومية)."
            ),
            foodSources = BiText(
                "Extra-virgin olive oil, avocado, wild salmon, sardines, walnuts, almonds, chia seeds, flaxseeds, egg yolks.",
                "زيت الزيتون البكر، الأفوكادو، السلمون البري، السردين، الجوز، اللوز، بذور الشيا والكتان، وصفار البيض."
            ),
            absorptionTip = BiText(
                "Avoid heavy fats right before training so digestion stays light; include them in main recovery meals.",
                "قلّل الدهون الثقيلة مباشرة قبل التمرين ليبقى الهضم خفيفاً، وأضفها لوجباتك الرئيسية والاستشفائية."
            )
        ),
        NutrientGuideItem(
            id = "fiber",
            group = NutrientGroup.MACRO,
            name = BiText("Dietary Fibre", "الألياف الغذائية"),
            subtitle = BiText("Gut Microbiome & Satiety", "صحة الأمعاء والشبع"),
            role = BiText(
                "Slows blood sugar spikes, feeds beneficial gut bacteria, supports regular digestion, and keeps hunger controlled during fat loss.",
                "تُبطئ ارتفاع السكر في الدم، وتغذي البكتيريا النافعة في الأمعاء، وتنظم الهضم، وتزيد الشبع أثناء فترات حرق الدهون."
            ),
            dailyTarget = BiText(
                "30 – 38 g daily for adult men.",
                "30 – 38 غ يومياً للرجال البالغين."
            ),
            foodSources = BiText(
                "Oats, chia seeds, lentils, chickpeas, broccoli, spinach, berries, apples, pears, sweet potatoes.",
                "الشوفان، بذور الشيا، العدس، الحمص، البروكلي، السبانخ، التوت، التفاح، الكمثرى، والبطاطا الحلوة."
            ),
            absorptionTip = BiText(
                "Increase fibre gradually and drink plenty of water so it works smoothly without bloating.",
                "ارفع كمية الألياف تدريجياً مع شرب كمية كافية من الماء لتفادي الانتفاخ."
            )
        ),
        NutrientGuideItem(
            id = "water",
            group = NutrientGroup.MACRO,
            name = BiText("Water & Electrolytes", "الماء والأملاح المعدنية"),
            subtitle = BiText("Cellular Hydration & Contraction", "ترطيب الخلايا والانقباض العضلي"),
            role = BiText(
                "Regulates body temperature, transports nutrients, lubricates joints, and prevents cramps and drops in strength or focus.",
                "ينظم حرارة الجسم، وينقل العناصر الغذائية، ويلين المفاصل، ويمنع التقلصات العضلية وهبوط القوة والتركيز."
            ),
            dailyTarget = BiText(
                "3 – 4 litres daily (more with heavy sweating).",
                "3 – 4 لترات يومياً (وتزيد مع التعرق الشديد)."
            ),
            foodSources = BiText(
                "Pure water, coconut water, cucumbers, watermelon, oranges, broth, and a pinch of sea salt during long sessions.",
                "الماء النقي، ماء جوز الهند، الخيار، البطيخ، البرتقال، المرق، ورشة ملح بحري أثناء التمارين الطويلة."
            ),
            absorptionTip = BiText(
                "Drink 400–500 ml upon waking and sip steadily rather than chugging huge amounts at once.",
                "اشرب 400–500 مل عند الاستيقاظ وتناول الماء على دفعات منتظمة طوال اليوم."
            )
        ),

        // ================= VITAMINS =================
        NutrientGuideItem(
            id = "vit_d",
            group = NutrientGroup.VITAMIN,
            name = BiText("Vitamin D", "فيتامين D"),
            subtitle = BiText("Strength, Bones & Testosterone Support", "القوة العضلية، العظام ودعم الهرمونات"),
            role = BiText(
                "Boosts calcium absorption for strong bones, supports muscle force output, immune defence, and healthy hormone balance.",
                "يعزز امتصاص الكالسيوم لقوة العظام، ويدعم قوة الانقباض العضلي والمناعة والتوازن الهرموني والمزاج."
            ),
            dailyTarget = BiText(
                "600 – 2,000 IU daily (check blood levels if sun exposure is low).",
                "600 – 2000 وحدة دولية يومياً (يفضّل فحص مستواه عند قلة التعرض للشمس)."
            ),
            foodSources = BiText(
                "Morning sunlight (15–20 min), wild salmon, sardines, mackerel, egg yolks, fortified milk.",
                "أشعة الشمس الصباحية (15–20 دقيقة)، السلمون، السردين، الماكريل، صفار البيض، والحليب المدعّم."
            ),
            absorptionTip = BiText(
                "Fat-soluble: always take Vitamin D foods or supplements alongside a meal containing healthy fat.",
                "يذوب في الدهون: تناوله دائماً مع وجبة تحتوي على دهون صحية مثل زيت الزيتون أو البيض."
            )
        ),
        NutrientGuideItem(
            id = "vit_b",
            group = NutrientGroup.VITAMIN,
            name = BiText("B-Complex Vitamins (B1, B6, B12)", "مجموعة فيتامينات B"),
            subtitle = BiText("Cellular Energy & Nerve Signalling", "إنتاج الطاقة وإشارات الأعصاب"),
            role = BiText(
                "Converts carbs, fats and protein into usable ATP energy, builds red blood cells (B12/Folate), and protects nerve signalling.",
                "تحوّل الكربوهيدرات والدهون والبروتين إلى طاقة (ATP)، وتدعم إنتاج كريات الدم الحمراء ونقل الإشارات العصبية للعضلات."
            ),
            dailyTarget = BiText(
                "B12: 2.4 mcg · B6: 1.3–1.7 mg · Folate: 400 mcg daily.",
                "B12: 2.4 ميكروغرام · B6: 1.3–1.7 ملغ · حمض الفوليك: 400 ميكروغرام يومياً."
            ),
            foodSources = BiText(
                "Lean beef, salmon, chicken, eggs, dairy, leafy greens (spinach), oats, legumes, nutritional yeast.",
                "اللحم البقري، السلمون، الدجاج، البيض، الألبان، السبانخ، الشوفان، والبقوليات."
            ),
            absorptionTip = BiText(
                "Water-soluble and used rapidly during intense training; replenish daily through varied whole foods.",
                "تذوب في الماء وتُستهلك بسرعة مع التمرين الشديد، لذا تجب تغطيتها يومياً من مصادر متنوعة."
            )
        ),
        NutrientGuideItem(
            id = "vit_c",
            group = NutrientGroup.VITAMIN,
            name = BiText("Vitamin C", "فيتامين C"),
            subtitle = BiText("Collagen, Tendons & Iron Absorption", "الكولاجين والأوتار وامتصاص الحديد"),
            role = BiText(
                "Mandatory cofactor for collagen synthesis in tendons and ligaments, antioxidant protection, immunity, and boosting plant iron uptake.",
                "عنصر أساسي لتصنيع الكولاجين في الأوتار والأربطة والمفاصل، ومضاد أكسدة قوي، ويرفع امتصاص الحديد النباتي."
            ),
            dailyTarget = BiText(
                "90 – 200 mg daily.",
                "90 – 200 ملغ يومياً."
            ),
            foodSources = BiText(
                "Bell peppers, kiwi, strawberries, oranges, lemon juice, broccoli, tomatoes, guava.",
                "الفلفل الرومي، الكيوي، الفراولة، البرتقال، الليمون، البروكلي، الطماطم، والجوافة."
            ),
            absorptionTip = BiText(
                "Squeeze fresh lemon over spinach or meat meals to multiply iron absorption.",
                "اعصر الليمون الطازج فوق السبانخ أو اللحم لمضاعفة امتصاص الحديد."
            )
        ),
        NutrientGuideItem(
            id = "vit_a",
            group = NutrientGroup.VITAMIN,
            name = BiText("Vitamin A", "فيتامين A"),
            subtitle = BiText("Vision, Immunity & Tissue Repair", "النظر والمناعة وتجديد الأنسجة"),
            role = BiText(
                "Supports vision, immune barrier integrity, skin health, and cellular protein synthesis during tissue recovery.",
                "يدعم حدة البصر، وقوة المناعة، وصحة الجلد، وتجديد الخلايا والأنسجة خلال الاستشفاء."
            ),
            dailyTarget = BiText(
                "900 mcg RAE daily for men.",
                "900 ميكروغرام يومياً للرجال."
            ),
            foodSources = BiText(
                "Sweet potatoes, carrots, spinach, kale, eggs, beef liver.",
                "البطاطا الحلوة، الجزر، السبانخ، الكيل، البيض، وكبد البقر."
            ),
            absorptionTip = BiText(
                "Drizzle olive oil on carrots or roasted sweet potato to absorb beta-carotene efficiently.",
                "أضف زيت الزيتون على الجزر أو البطاطا الحلوة المشوية لتحسين امتصاص البيتا كاروتين."
            )
        ),
        NutrientGuideItem(
            id = "vit_e",
            group = NutrientGroup.VITAMIN,
            name = BiText("Vitamin E", "فيتامين E"),
            subtitle = BiText("Cell Membrane Antioxidant", "حماية أغشية الخلايا"),
            role = BiText(
                "Protects muscle cell membranes from oxidative stress generated during intense anaerobic sessions.",
                "يحمي أغشية الخلايا العضلية من الأكسدة الناتجة عن التمارين الشديدة ويدعم الدورة الدموية."
            ),
            dailyTarget = BiText(
                "15 mg daily.",
                "15 ملغ يومياً."
            ),
            foodSources = BiText(
                "Almonds, sunflower seeds, hazelnuts, avocado, spinach, olive oil.",
                "اللوز، بذور دوار الشمس، البندق، الأفوكادو، السبانخ، وزيت الزيتون."
            ),
            absorptionTip = BiText(
                "Get it from whole nuts and seeds rather than mega-dose pills which can blunt training adaptations.",
                "احصل عليه من المكسرات والبذور الطبيعية بدلاً من الجرعات الدوائية العالية."
            )
        ),
        NutrientGuideItem(
            id = "vit_k",
            group = NutrientGroup.VITAMIN,
            name = BiText("Vitamin K (K1 & K2)", "فيتامين K (K1 و K2)"),
            subtitle = BiText("Bone Mineralization & Blood Clotting", "تمعدن العظام وتخثر الدم"),
            role = BiText(
                "Works alongside Vitamin D to direct calcium into bones rather than soft tissues, and supports normal blood clotting.",
                "يعمل مع فيتامين D لتوجيه الكالسيوم نحو العظام والأسنان بدلاً من ترسبه، وينظم تخثر الدم."
            ),
            dailyTarget = BiText(
                "120 mcg daily for men.",
                "120 ميكروغرام يومياً للرجال."
            ),
            foodSources = BiText(
                "K1: spinach, kale, broccoli, green beans. K2: egg yolks, fermented foods, aged cheese.",
                "K1: السبانخ، البروكلي، الفاصوليا الخضراء. K2: صفار البيض، الأطعمة المخمرة، والأجبان المعتّقة."
            ),
            absorptionTip = BiText(
                "Pair dark leafy greens with olive oil or avocado for full fat-soluble absorption.",
                "تناول الخضار الورقية الداكنة مع زيت الزيتون أو الأفوكادو لامتصاص مثالي."
            )
        ),

        // ================= MINERALS =================
        NutrientGuideItem(
            id = "iron",
            group = NutrientGroup.MINERAL,
            name = BiText("Iron", "الحديد"),
            subtitle = BiText("Oxygen Transport & Stamina", "نقل الأكسجين والقدرة على التحمل"),
            role = BiText(
                "Core component of haemoglobin and myoglobin; delivers oxygen to working muscles and prevents fatigue and shortness of breath.",
                "المكون الأساسي للهيموغلوبين والميوغلوبين لنقل الأكسجين إلى العضلات العاملة، ويمنع الإرهاق وهبوط اللياقة."
            ),
            dailyTarget = BiText(
                "8 mg daily for men.",
                "8 ملغ يومياً للرجال."
            ),
            foodSources = BiText(
                "Heme (high absorption): lean beef, sardines, turkey, liver. Non-heme: spinach, lentils, pumpkin seeds.",
                "حيواني (أعلى امتصاصاً): اللحم البقري، السردين، الديك الرومي، الكبد. نباتي: السبانخ، العدس، بذور اليقطين."
            ),
            absorptionTip = BiText(
                "Avoid tea or coffee within 1 hour of iron-rich meals; combine with Vitamin C instead.",
                "تجنّب الشاي أو القهوة قبل أو بعد وجبة الحديد بساعة، وادمجها مع مصدر لفيتامين C."
            )
        ),
        NutrientGuideItem(
            id = "magnesium",
            group = NutrientGroup.MINERAL,
            name = BiText("Magnesium", "المغنيسيوم"),
            subtitle = BiText("Muscle Relaxation, ATP & Deep Sleep", "ارتخاء العضلات والطاقة والنوم العميق"),
            role = BiText(
                "Involved in 300+ enzymatic reactions including ATP energy production, muscle relaxation, nerve calm, and deep sleep recovery.",
                "يشارك في أكثر من 300 تفاعل إنزيمي تشمل إنتاج الطاقة (ATP)، واسترخاء العضلات، وتهدئة الأعصاب، وجودة النوم العميق."
            ),
            dailyTarget = BiText(
                "400 – 420 mg daily for men.",
                "400 – 420 ملغ يومياً للرجال."
            ),
            foodSources = BiText(
                "Pumpkin seeds, almonds, dark chocolate (70%+), cacao, spinach, quinoa, avocado, bananas.",
                "بذور اليقطين، اللوز، الشوكولاتة الداكنة، الكاكاو، السبانخ، الكينوا، الأفوكادو، والموز."
            ),
            absorptionTip = BiText(
                "Consuming magnesium-rich foods in the evening supports calmer nervous system recovery.",
                "تناول مصادر المغنيسيوم مساءً يساعد على تهدئة الجهاز العصبي وتحسين جودة النوم."
            )
        ),
        NutrientGuideItem(
            id = "zinc",
            group = NutrientGroup.MINERAL,
            name = BiText("Zinc", "الزنك"),
            subtitle = BiText("Immunity, Repair & Hormone Health", "المناعة، الإصلاح وصحة الهرمونات"),
            role = BiText(
                "Supports protein synthesis, wound & micro-tear healing, immune defence, and healthy testosterone metabolism.",
                "يدعم تصنيع البروتين، والتئام التمزقات العضلية الدقيقة، والمناعة، وإنتاج هرمون التستوستيرون."
            ),
            dailyTarget = BiText(
                "11 mg daily for men.",
                "11 ملغ يومياً للرجال."
            ),
            foodSources = BiText(
                "Lean beef, oysters, chicken, pumpkin seeds, chickpeas, eggs, cashews.",
                "اللحم البقري، المحار، الدجاج، بذور اليقطين، الحمص، البيض، والكاجو."
            ),
            absorptionTip = BiText(
                "Animal zinc is absorbed more easily; soak legumes before cooking to reduce phytates.",
                "الزنك من المصادر الحيوانية أسهل امتصاصاً؛ وانقع البقوليات قبل الطهي لتقليل الفيتات المعيقة."
            )
        ),
        NutrientGuideItem(
            id = "calcium",
            group = NutrientGroup.MINERAL,
            name = BiText("Calcium", "الكالسيوم"),
            subtitle = BiText("Bone Density & Muscle Contraction", "كثافة العظام وانقباض العضلات"),
            role = BiText(
                "Builds bone mineral density to withstand calisthenics & plyometrics, and triggers every muscle fibre contraction.",
                "يبني كثافة العظام لتحمل تمارين القوة والقفز، ويحفز انقباض كل ليفة عضلية ونقل الإشارات العصبية."
            ),
            dailyTarget = BiText(
                "1,000 mg daily.",
                "1000 ملغ يومياً."
            ),
            foodSources = BiText(
                "Greek yogurt, milk, kefir, cottage cheese, sardines with bones, sesame seeds, tahini, broccoli.",
                "الزبادي اليوناني، الحليب، الكفير، جبنة القريش، السردين، السمسم، الطحينة، والبروكلي."
            ),
            absorptionTip = BiText(
                "Needs adequate Vitamin D for proper intestinal absorption.",
                "يحتاج وجود فيتامين D بمستوى كافٍ ليتم امتصاصه بكفاءة في الأمعاء."
            )
        ),
        NutrientGuideItem(
            id = "potassium",
            group = NutrientGroup.MINERAL,
            name = BiText("Potassium", "البوتاسيوم"),
            subtitle = BiText("Fluid Balance & Cramp Prevention", "توازن السوائل ومنع الشد العضلي"),
            role = BiText(
                "Maintains intracellular fluid balance, nerve impulses, steady heart rhythm, and helps prevent muscle cramps.",
                "يحافظ على توازن السوائل داخل الخلايا، وانتظام نبض القلب، وقوة الإشارات العصبية، ويمنع الشد العضلي."
            ),
            dailyTarget = BiText(
                "3,400 mg daily for men.",
                "3400 ملغ يومياً للرجال."
            ),
            foodSources = BiText(
                "Sweet potatoes, potatoes, bananas, avocado, salmon, spinach, coconut water, dates.",
                "البطاطا الحلوة، البطاطس، الموز، الأفوكادو، السلمون، السبانخ، ماء جوز الهند، والتمر."
            ),
            absorptionTip = BiText(
                "Include a potassium-rich carb source in your post-workout meal to help glycogen storage.",
                "أضف مصدراً غنياً بالبوتاسيوم في وجبة ما بعد التمرين لدعم تخزين الجلايكوجين."
            )
        ),
        NutrientGuideItem(
            id = "sodium",
            group = NutrientGroup.MINERAL,
            name = BiText("Sodium", "الصوديوم"),
            subtitle = BiText("Sweat Replacement & Muscle Pump", "تعويض التعرق والضخ العضلي"),
            role = BiText(
                "Regulates blood volume, nerve firing, and fluid retention; athletes lose significant sodium through sweat.",
                "ينظم حجم الدم وضغطه ونقل الإشارات العصبية، ويفقده الرياضي بكمية كبيرة مع العرق أثناء التمرين."
            ),
            dailyTarget = BiText(
                "1,500 – 2,300 mg daily (higher for heavy sweaters).",
                "1500 – 2300 ملغ يومياً (تزيد لمن يتعرقون بغزارة)."
            ),
            foodSources = BiText(
                "Sea salt, table salt, pickles, olives, broth, cheese.",
                "الملح البحري، ملح الطعام، المخللات، الزيتون، المرق، والأجبان."
            ),
            absorptionTip = BiText(
                "Season whole-food meals lightly to taste rather than avoiding salt completely when training hard.",
                "تبّل وجباتك الطبيعية بقدر معتدل بدلاً من قطع الملح كلياً عند ممارسة الرياضة بانتظام."
            )
        )
    )
}
