package com.example.viewmodel

import android.app.Application
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ExerciseData
import com.example.data.NutritionData
import com.example.data.PreferencesRepository
import com.example.data.StringsData
import com.example.model.ActiveSessionState
import com.example.model.ApexUiState
import com.example.model.AppLanguage
import com.example.model.AppTab
import com.example.model.BiText
import com.example.model.ChatMessage
import com.example.model.Equipment
import com.example.model.Exercise
import com.example.model.ExerciseCategory
import com.example.model.FactCategory
import com.example.model.NutrientGroup
import com.example.model.PsychState
import com.example.model.RegimenLevel
import com.example.model.ResolvedWorkoutExercise
import com.example.model.SessionItem
import com.example.model.SessionPhase
import com.example.model.TensionZone
import com.example.model.WorkoutPlan
import com.example.model.ZoneStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

class ApexViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val repo = PreferencesRepository(application)
    private val _uiState = MutableStateFlow(ApexUiState())
    val uiState: StateFlow<ApexUiState> = _uiState.asStateFlow()

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var restTimerJob: Job? = null
    private var toastJob: Job? = null
    private val toneGen: ToneGenerator? = runCatching {
        ToneGenerator(AudioManager.STREAM_MUSIC, 60)
    }.getOrNull()

    init {
        tts = TextToSpeech(application, this)
        viewModelScope.launch {
            val loaded = repo.loadInitialState(::computeRecovery)
            _uiState.value = loaded
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _uiState.update { it.copy(isSpeaking = true) }
                }

                override fun onDone(utteranceId: String?) {
                    _uiState.update { it.copy(isSpeaking = false) }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _uiState.update { it.copy(isSpeaking = false) }
                }
            })
        }
    }

    fun selectTab(tab: AppTab) {
        _uiState.update { it.copy(tab = tab) }
    }

    fun toggleLanguage() {
        val next = if (_uiState.value.language == AppLanguage.AR) AppLanguage.EN else AppLanguage.AR
        updateAndSave { it.copy(language = next) }
        showToast(if (next.isArabic) "تم التحويل إلى العربية" else "Switched to English")
    }

    fun toggleStreakDay(index: Int) {
        updateAndSave { s ->
            val updated = s.streakDays.toMutableList()
            if (index in updated.indices) updated[index] = !updated[index]
            s.copy(streakDays = updated)
        }
    }

    fun setProgramFilter(programId: String?) {
        _uiState.update { it.copy(programFilter = programId) }
    }

    fun setExerciseCategoryFilter(category: ExerciseCategory?) {
        _uiState.update { it.copy(exerciseCategoryFilter = category) }
    }

    fun setExerciseQuery(query: String) {
        _uiState.update { it.copy(exerciseQuery = query) }
    }

    fun openWorkout(workoutId: String?) {
        _uiState.update { it.copy(selectedWorkoutId = workoutId, selectedExerciseId = null) }
    }

    fun openExerciseGuide(exerciseId: String?) {
        _uiState.update { it.copy(selectedExerciseId = exerciseId) }
    }

    fun setPsychState(psych: PsychState) {
        updateAndSave { s ->
            val rec = computeRecovery(psych, s.sleepHours, s.hrvMs, s.rhrBpm, s.zones)
            s.copy(psych = psych, recoveryPercent = rec)
        }
    }

    fun updateSleep(hours: Float) {
        val snapped = ((hours * 4f).roundToInt() / 4f).coerceIn(4f, 10f)
        updateAndSave { s ->
            val rec = computeRecovery(s.psych, snapped, s.hrvMs, s.rhrBpm, s.zones)
            s.copy(sleepHours = snapped, recoveryPercent = rec)
        }
    }

    fun updateHrv(hrv: Int) {
        val clamped = hrv.coerceIn(30, 100)
        updateAndSave { s ->
            val rec = computeRecovery(s.psych, s.sleepHours, clamped, s.rhrBpm, s.zones)
            s.copy(hrvMs = clamped, recoveryPercent = rec)
        }
    }

    fun updateRhr(rhr: Int) {
        val clamped = rhr.coerceIn(40, 70)
        updateAndSave { s ->
            val rec = computeRecovery(s.psych, s.sleepHours, s.hrvMs, clamped, s.zones)
            s.copy(rhrBpm = clamped, recoveryPercent = rec)
        }
    }

    fun cycleZone(zone: TensionZone) {
        updateAndSave { s ->
            val nextZones = s.zones.toMutableMap()
            nextZones[zone] = (nextZones[zone] ?: ZoneStatus.FRESH).next()
            val rec = computeRecovery(s.psych, s.sleepHours, s.hrvMs, s.rhrBpm, nextZones)
            s.copy(zones = nextZones, recoveryPercent = rec)
        }
    }

    fun toggleEquipment(eq: Equipment) {
        updateAndSave { s ->
            val updated = if (eq == Equipment.NONE) {
                emptySet()
            } else {
                val m = s.ownedEquipment.toMutableSet()
                if (eq in m) m.remove(eq) else m.add(eq)
                m
            }
            s.copy(ownedEquipment = updated)
        }
    }

    fun applyAndGenerateRegimen() {
        val s = _uiState.value
        val r = computeRecovery(s.psych, s.sleepHours, s.hrvMs, s.rhrBpm, s.zones)
        val level = when {
            r < 60 || s.psych == PsychState.DRAINED || s.psych == PsychState.FATIGUED -> RegimenLevel.DELOAD
            r >= 85 && (s.psych == PsychState.FOCUSED || s.psych == PsychState.PEAK) -> RegimenLevel.BUILD
            else -> RegimenLevel.MAINTAIN
        }
        val wid = when (level) {
            RegimenLevel.DELOAD -> "mob1"
            RegimenLevel.BUILD -> "planche"
            RegimenLevel.MAINTAIN -> "hs"
        }
        val regimen = PreferencesRepository.buildRegimenNote(level, wid, r, s.psych, s.ownedEquipment)
        updateAndSave { it.copy(recoveryPercent = r, regimen = regimen, tab = AppTab.WORKOUTS) }
        showToast(StringsData.regenOk.get(_uiState.value.language))
    }

    fun toggleVoiceHud() {
        val next = !_uiState.value.voiceEnabled
        if (!next) {
            tts?.stop()
        }
        updateAndSave { it.copy(voiceEnabled = next, isSpeaking = if (next) it.isSpeaking else false) }
        val lang = _uiState.value.language
        showToast(if (next) StringsData.voiceEnabledToast.get(lang) else StringsData.voiceDisabledToast.get(lang))
    }

    fun applyShoulderSwap() {
        updateAndSave { it.copy(swappedShoulderProtocol = true) }
        showToast(StringsData.swapApplied.get(_uiState.value.language))
    }

    fun sendChatMessage(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        val lower = text.lowercase()
        val s = _uiState.value
        val userMsg = ChatMessage(
            id = "u_${System.currentTimeMillis()}",
            isUser = true,
            text = BiText(text, text)
        )
        val replyMsg = when {
            Regex("shoulder|pinch|elbow|wrist|كتف|ألم|وخز|pain|hurt").containsMatchIn(lower) ->
                ChatMessage(id = "b_${System.currentTimeMillis()}", isUser = false, isSwapCard = true)
            Regex("squat|form|depth|knee|قرفصاء|وضعية|فورم|ركبة").containsMatchIn(lower) ->
                ChatMessage(id = "b_${System.currentTimeMillis()}", isUser = false, text = StringsData.coachForm)
            Regex("recover|sleep|tired|rest|استشفاء|نوم|تعب").containsMatchIn(lower) ->
                ChatMessage(id = "b_${System.currentTimeMillis()}", isUser = false, text = StringsData.coachRecovery(s.recoveryPercent))
            Regex("protein|food|eat|meal|nutrition|diet|بروتين|أكل|وجبة|تغذية").containsMatchIn(lower) ->
                ChatMessage(id = "b_${System.currentTimeMillis()}", isUser = false, text = StringsData.coachProtein)
            else ->
                ChatMessage(id = "b_${System.currentTimeMillis()}", isUser = false, text = StringsData.coachDefault)
        }
        _uiState.update { it.copy(chatMessages = it.chatMessages + userMsg + replyMsg) }
        val spoken = replyMsg.text ?: if (replyMsg.isSwapCard) StringsData.coachSwap else null
        if (spoken != null) speak(spoken.get(_uiState.value.language))
    }

    fun addWater250() {
        updateAndSave { s ->
            s.copy(waterMl = (s.waterMl + 250).coerceAtMost(4000))
        }
    }

    fun logRecipe(index: Int) {
        val recipe = NutritionData.recipes.getOrNull(index) ?: return
        updateAndSave { s ->
            s.copy(
                loggedMacros = s.loggedMacros.copy(
                    kcal = s.loggedMacros.kcal + recipe.kcal,
                    proteinG = s.loggedMacros.proteinG + recipe.proteinG,
                    carbsG = s.loggedMacros.carbsG + recipe.carbsG,
                    fatsG = s.loggedMacros.fatsG + recipe.fatsG
                )
            )
        }
        val lang = _uiState.value.language
        showToast("${StringsData.loggedTo.get(lang)} · ${recipe.name.get(lang)}")
    }

    fun setFactQuery(query: String) {
        _uiState.update { it.copy(factQuery = query) }
    }

    fun setFactCategoryFilter(category: FactCategory?) {
        _uiState.update { it.copy(factCategoryFilter = category) }
    }

    fun setNutrientFilter(group: NutrientGroup?) {
        _uiState.update { it.copy(nutrientFilter = group) }
    }

    fun addToCart(gearIndex: Int) {
        val item = NutritionData.gear.getOrNull(gearIndex) ?: return
        updateAndSave { it.copy(cartIndices = it.cartIndices + gearIndex) }
        val lang = _uiState.value.language
        showToast("${StringsData.addedTo.get(lang)} · ${item.name.get(lang)}")
    }

    fun clearCart() {
        updateAndSave { it.copy(cartIndices = emptyList()) }
    }

    fun showNoAlertsToast() {
        showToast(StringsData.noAlerts.get(_uiState.value.language))
    }

    fun resolveExercise(exerciseId: String, state: ApexUiState = _uiState.value): Exercise {
        val base = ExerciseData.exercisesById[exerciseId] ?: ExerciseData.exercises.first()
        val hasGear = base.requiredEquipment.all { it in state.ownedEquipment }
        var resolvedId = if (!hasGear && base.fallbackId != null) base.fallbackId else exerciseId
        if (state.swappedShoulderProtocol && resolvedId == "wall-hspu") {
            resolvedId = "deficit-pike"
        }
        return ExerciseData.exercisesById[resolvedId] ?: base
    }

    fun resolveWorkoutExercises(workout: WorkoutPlan, state: ApexUiState = _uiState.value): List<ResolvedWorkoutExercise> {
        return workout.exercises.map { spec ->
            ResolvedWorkoutExercise(
                exercise = resolveExercise(spec.exerciseId, state),
                sets = spec.sets,
                reps = spec.reps,
                tempoSec = spec.tempoSec,
                restSec = spec.restSec
            )
        }
    }

    fun heroWorkout(state: ApexUiState = _uiState.value): WorkoutPlan {
        val id = state.regimen?.workoutId ?: "planche"
        return ExerciseData.workoutsById[id] ?: ExerciseData.workouts.first()
    }

    /* ======== LIVE GUIDED SESSION ======== */

    fun startWorkoutSession(workoutId: String) {
        val wo = ExerciseData.workoutsById[workoutId] ?: return
        val resolved = resolveWorkoutExercises(wo)
        val seq = buildList {
            resolved.forEach { rx ->
                for (setNum in 1..rx.sets) {
                    add(SessionItem(rx, setNum))
                }
            }
        }
        restTimerJob?.cancel()
        _uiState.update {
            it.copy(
                selectedWorkoutId = null,
                selectedExerciseId = null,
                activeSession = ActiveSessionState(
                    workout = wo,
                    sequence = seq,
                    currentIndex = 0,
                    phase = SessionPhase.WORK,
                    isPlayingFigure = true
                )
            )
        }
    }

    fun onSessionRepCompleted(newRep: Int) {
        toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP, 70)
        val session = _uiState.value.activeSession ?: return
        val item = session.sequence.getOrNull(session.currentIndex) ?: return
        if (newRep >= item.exercise.reps) {
            finishCurrentSessionSet()
        } else {
            _uiState.update { s ->
                s.activeSession?.let { active ->
                    s.copy(activeSession = active.copy(currentReps = newRep))
                } ?: s
            }
        }
    }

    fun finishCurrentSessionSet() {
        val session = _uiState.value.activeSession ?: return
        val currentItem = session.sequence.getOrNull(session.currentIndex) ?: return
        val nextIndex = session.currentIndex + 1
        if (nextIndex >= session.sequence.size) {
            completeSession()
            return
        }
        val restSec = currentItem.exercise.restSec
        _uiState.update { s ->
            s.copy(
                activeSession = session.copy(
                    currentIndex = nextIndex,
                    phase = SessionPhase.REST,
                    restSecondsLeft = restSec,
                    isPlayingFigure = false,
                    currentReps = 0
                )
            )
        }
        startRestCountdown()
    }

    fun skipSessionRest() {
        restTimerJob?.cancel()
        val session = _uiState.value.activeSession ?: return
        _uiState.update {
            it.copy(
                activeSession = session.copy(
                    phase = SessionPhase.WORK,
                    restSecondsLeft = 0,
                    isPlayingFigure = !session.isPaused,
                    currentReps = 0
                )
            )
        }
    }

    fun toggleSessionPause() {
        val session = _uiState.value.activeSession ?: return
        val nextPaused = !session.isPaused
        _uiState.update {
            it.copy(
                activeSession = session.copy(
                    isPaused = nextPaused,
                    isPlayingFigure = !nextPaused && session.phase == SessionPhase.WORK
                )
            )
        }
    }

    fun endWorkoutSession() {
        restTimerJob?.cancel()
        _uiState.update { it.copy(activeSession = null) }
    }

    private fun startRestCountdown() {
        restTimerJob?.cancel()
        restTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val session = _uiState.value.activeSession ?: break
                if (session.phase != SessionPhase.REST) break
                if (session.isPaused) continue
                val nextLeft = session.restSecondsLeft - 1
                if (nextLeft <= 0) {
                    skipSessionRest()
                    break
                } else {
                    _uiState.update { s ->
                        s.activeSession?.let { active ->
                            s.copy(activeSession = active.copy(restSecondsLeft = nextLeft))
                        } ?: s
                    }
                }
            }
        }
    }

    private fun completeSession() {
        restTimerJob?.cancel()
        val session = _uiState.value.activeSession ?: return
        updateAndSave { s ->
            val days = s.streakDays.toMutableList()
            if (days.size > 4) days[4] = true
            s.copy(
                streakDays = days,
                activeSession = session.copy(
                    phase = SessionPhase.COMPLETE,
                    isPlayingFigure = false
                )
            )
        }
    }

    private fun speak(text: String) {
        if (!_uiState.value.voiceEnabled || !ttsReady) return
        val locale = if (_uiState.value.language.isArabic) Locale("ar", "SA") else Locale.US
        tts?.language = locale
        tts?.setSpeechRate(1.0f)
        val params = Bundle()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "apex_${System.currentTimeMillis()}")
    }

    private fun computeRecovery(
        psych: PsychState,
        sleep: Float,
        hrv: Int,
        rhr: Int,
        zones: Map<TensionZone, ZoneStatus>
    ): Int {
        val zAvg = zones.values.map { it.pct.toFloat() }.average().toFloat()
        val raw = 66f + (sleep - 6f) * 6f + (hrv - 55) * 0.35f + (55 - rhr) * 0.4f + (zAvg - 85f) * 0.5f + psych.delta
        return raw.roundToInt().coerceIn(20, 99)
    }

    private fun updateAndSave(transform: (ApexUiState) -> ApexUiState) {
        _uiState.update(transform)
        val snapshot = _uiState.value
        viewModelScope.launch { repo.saveState(snapshot) }
    }

    private fun showToast(msg: String) {
        toastJob?.cancel()
        _uiState.update { it.copy(toastMessage = msg) }
        toastJob = viewModelScope.launch {
            delay(2100L)
            _uiState.update { it.copy(toastMessage = null) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        restTimerJob?.cancel()
        tts?.stop()
        tts?.shutdown()
        toneGen?.release()
    }
}
