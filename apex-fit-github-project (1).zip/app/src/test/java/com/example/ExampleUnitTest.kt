package com.example

import com.example.data.ExerciseData
import com.example.data.NutritionAcademyData
import com.example.data.NutritionData
import com.example.model.ApexUiState
import com.example.model.AppLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun default_language_is_arabic() {
        val state = ApexUiState()
        assertEquals(AppLanguage.AR, state.language)
    }

    @Test
    fun all_100_food_facts_and_5_recipes_with_benefits_exist_bilingually() {
        assertEquals(100, NutritionData.facts.size)
        assertEquals(5, NutritionData.recipes.size)
        assertEquals(8, NutritionData.gear.size)
        assertTrue(NutritionData.facts.all { it.title.ar.isNotBlank() && it.title.en.isNotBlank() })
        assertTrue(
            NutritionData.recipes.all {
                it.name.ar.isNotBlank() && it.benefit.ar.isNotBlank() && it.benefit.en.isNotBlank() && it.steps.ar.isNotEmpty()
            }
        )
    }

    @Test
    fun nutrition_academy_covers_macros_vitamins_and_minerals_bilingually() {
        assertEquals(17, NutritionAcademyData.nutrients.size)
        assertTrue(
            NutritionAcademyData.nutrients.all {
                it.name.ar.isNotBlank() && it.role.ar.isNotBlank() && it.foodSources.ar.isNotBlank() && it.dailyTarget.ar.isNotBlank()
            }
        )
    }

    @Test
    fun all_35_exercises_and_9_workouts_exist_bilingually() {
        assertEquals(35, ExerciseData.exercises.size)
        assertEquals(9, ExerciseData.workouts.size)
        assertEquals(4, ExerciseData.programs.size)
        assertTrue(ExerciseData.exercises.all { it.name.ar.isNotBlank() && it.steps.ar.size == 3 })
    }
}
